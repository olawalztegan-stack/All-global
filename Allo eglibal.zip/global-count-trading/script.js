// Global Count Trading - No Loss No Regrets
// 11-Person Matrix Contribution System
// Owner: Olawale Abdul-Ganiyu

// ==================== GLOBAL VARIABLES ====================
let currentUser = null;
let isAdmin = false;

let systemData = {
    users: [],
    pools: [],
    transactions: [],
    messages: [],
    adminBalance: 0,
    totalRevenue: 0,
    totalCharges: 0
};

// Investment plans
const investmentPlans = [10000, 100000, 200000, 300000, 400000, 500000, 600000];

// Charges breakdown (10%)
const charges = {
    monitoring: 5000,
    webMaintenance: 1000,
    administrative: 1000,
    currentAccount: 1000,
    transactions: 1000,
    robot: 500,
    vat: 1000,
    total: 10500
};

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    
    // Check if user is logged in
    const loggedInUser = localStorage.getItem('currentUser');
    if (loggedInUser) {
        currentUser = JSON.parse(loggedInUser);
        if (currentUser.email === 'adeganglobal@gmail.com') {
            isAdmin = true;
            showAdminDashboard();
        } else {
            showCustomerDashboard();
        }
    }
    
    // Withdrawal amount listener
    document.getElementById('withdrawAmount')?.addEventListener('input', calculateWithdrawalFee);
});

// ==================== AUTHENTICATION ====================
function showRegister() {
    document.getElementById('loginForm').classList.remove('active');
    document.getElementById('registerForm').classList.add('active');
}

function showLogin() {
    document.getElementById('registerForm').classList.remove('active');
    document.getElementById('loginForm').classList.add('active');
}

function handleRegister() {
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    const address = document.getElementById('regAddress').value;
    const password = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('regConfirmPassword').value;
    const passport = document.getElementById('regPassport').files[0];
    
    // Validation
    if (!name || !email || !phone || !address || !password) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }
    
    // Check if user already exists
    if (systemData.users.find(u => u.email === email)) {
        showNotification('Email already registered', 'error');
        return;
    }
    
    // Create user
    const user = {
        id: Date.now(),
        name: name,
        email: email,
        phone: phone,
        address: address,
        password: password,
        passport: passport ? passport.name : null,
        balance: 0,
        invested: 0,
        earnings: 0,
        status: 'pending', // pending, active, blocked
        joinDate: new Date().toISOString(),
        contributions: 0,
        payouts: 0,
        notificationSettings: {
            email: true,
            sms: true,
            pool: true,
            payout: true
        },
        currentPool: null,
        poolPosition: 0
    };
    
    systemData.users.push(user);
    saveToStorage();
    
    // Add pending registration for admin approval
    systemData.pendingRegistrations = systemData.pendingRegistrations || [];
    systemData.pendingRegistrations.push({
        userId: user.id,
        date: new Date().toISOString(),
        status: 'pending'
    });
    
    showNotification('Registration successful! Please wait for admin approval.', 'success');
    showLogin();
}

function handleLogin() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Check if admin
    if (email === 'adeganglobal@gmail.com' && password === 'admin123') {
        isAdmin = true;
        currentUser = {
            email: email,
            name: 'Olawale Abdul-Ganiyu',
            role: 'admin'
        };
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        showAdminDashboard();
        return;
    }
    
    // Check regular user
    const user = systemData.users.find(u => u.email === email && u.password === password);
    
    if (!user) {
        showNotification('Invalid email or password', 'error');
        return;
    }
    
    if (user.status === 'pending') {
        showNotification('Your account is pending approval', 'warning');
        return;
    }
    
    if (user.status === 'blocked') {
        showNotification('Your account has been blocked. Contact admin.', 'error');
        return;
    }
    
    currentUser = user;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    showCustomerDashboard();
    showNotification('Welcome back, ' + user.name + '!', 'success');
}

function logout() {
    currentUser = null;
    isAdmin = false;
    localStorage.removeItem('currentUser');
    
    document.getElementById('authSection').style.display = 'block';
    document.getElementById('customerDashboard').style.display = 'none';
    document.getElementById('adminDashboard').style.display = 'none';
    
    saveToStorage();
}

// ==================== DASHBOARD DISPLAY ====================
function showCustomerDashboard() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('adminDashboard').style.display = 'none';
    document.getElementById('customerDashboard').style.display = 'block';
    
    // Update user info
    const user = getCurrentUserData();
    if (user) {
        document.getElementById('customerName').textContent = user.name;
        document.getElementById('customerBalance').textContent = formatCurrency(user.balance);
        document.getElementById('totalInvested').textContent = formatCurrency(user.invested);
        document.getElementById('totalEarnings').textContent = formatCurrency(user.earnings);
        
        // Pool info
        document.getElementById('currentPoolPosition').textContent = user.poolPosition || 0;
        
        // Profile
        document.getElementById('profileName').textContent = user.name;
        document.getElementById('profileEmail').textContent = user.email;
        document.getElementById('profilePhone').textContent = user.phone;
        document.getElementById('profileAddress').textContent = user.address;
        document.getElementById('profileJoinDate').textContent = new Date(user.joinDate).toLocaleDateString();
        document.getElementById('profileContributions').textContent = user.contributions;
        document.getElementById('profilePayouts').textContent = user.payouts;
        
        // Wallet
        document.getElementById('walletMainBalance').textContent = formatCurrency(user.balance);
        document.getElementById('walletEarnings').textContent = formatCurrency(user.earnings);
        document.getElementById('walletInvested').textContent = formatCurrency(user.invested);
        
        // Withdrawal
        document.getElementById('withdrawAvailableBalance').textContent = formatCurrency(user.balance);
        
        // Update pool display
        updatePoolDisplay();
        
        // Update activity
        updateCustomerActivity();
    }
}

function showAdminDashboard() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('customerDashboard').style.display = 'none';
    document.getElementById('adminDashboard').style.display = 'block';
    
    // Update admin stats
    document.getElementById('adminTotalUsers').textContent = systemData.users.length;
    document.getElementById('adminActivePools').textContent = systemData.pools.length;
    document.getElementById('adminPendingApprovals').textContent = 
        (systemData.pendingRegistrations?.length || 0) + 
        (systemData.pendingDeposits?.length || 0) + 
        (systemData.pendingWithdrawals?.length || 0);
    document.getElementById('adminMessages').textContent = systemData.messages?.length || 0;
    
    // Calculate total balance
    const totalBalance = systemData.users.reduce((sum, u) => sum + (u.balance || 0), 0);
    document.getElementById('adminTotalBalance').textContent = formatCurrency(totalBalance);
    document.getElementById('adminBalance').textContent = formatCurrency(systemData.adminBalance);
    document.getElementById('totalCharges').textContent = formatCurrency(systemData.totalCharges || 0);
    document.getElementById('adminTotalRevenue').textContent = formatCurrency(systemData.totalRevenue || 0);
    
    // Render users
    renderUsersList();
    
    // Render pending approvals
    renderPendingApprovals();
}

// ==================== NAVIGATION ====================
function showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    document.getElementById(sectionId + 'Section').style.display = 'block';
    
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
}

function showAdminSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    document.getElementById('admin' + sectionId.charAt(0).toUpperCase() + sectionId.slice(1) + 'Section').style.display = 'block';
    
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
}

// ==================== INVESTMENT PLANS ====================
function selectPlan(amount) {
    const user = getCurrentUserData();
    
    if (user.balance < amount) {
        showNotification('Insufficient balance. Please deposit funds first.', 'error');
        return;
    }
    
    // Check if user is already in a pool
    if (user.currentPool) {
        showNotification('You are already in an active pool. Complete it before joining another.', 'warning');
        return;
    }
    
    // Deduct from balance
    user.balance -= amount;
    user.invested += amount;
    user.contributions += 1;
    
    // Find or create pool
    let pool = findOrCreatePool(amount);
    
    // Add user to pool
    pool.members.push({
        userId: user.id,
        name: user.name,
        joinDate: new Date().toISOString()
    });
    
    user.currentPool = pool.id;
    user.poolPosition = pool.members.length;
    
    // Add transaction
    addTransaction(user.id, 'debit', amount, `Joined ${formatCurrency(amount)} contribution plan`);
    
    // Check if pool is complete
    if (pool.members.length === 11) {
        completePool(pool);
    } else {
        // Notify other pool members
        notifyPoolMembers(pool);
    }
    
    saveToStorage();
    updateUI();
    
    showNotification(`Successfully joined ₦${formatCurrency(amount)} contribution plan!`, 'success');
    showSection('pool');
}

function findOrCreatePool(amount) {
    // Find incomplete pool with same amount
    let pool = systemData.pools.find(p => 
        p.amount === amount && 
        p.members.length < 11 && 
        p.status === 'active'
    );
    
    if (!pool) {
        // Create new pool
        pool = {
            id: Date.now(),
            amount: amount,
            members: [],
            status: 'active',
            createdDate: new Date().toISOString(),
            completedDate: null
        };
        systemData.pools.push(pool);
    }
    
    return pool;
}

function completePool(pool) {
    pool.status = 'completed';
    pool.completedDate = new Date().toISOString();
    
    // First member receives payment from 10 other members
    const firstMember = pool.members[0];
    const payoutAmount = pool.amount * 10;
    
    // Calculate charges (10%)
    const chargesAmount = charges.total;
    const payoutAfterCharges = payoutAmount - chargesAmount;
    
    // Credit first member
    const firstUser = systemData.users.find(u => u.id === firstMember.userId);
    if (firstUser) {
        firstUser.balance += payoutAfterCharges;
        firstUser.earnings += payoutAfterCharges;
        firstUser.payouts += 1;
        firstUser.currentPool = null;
        firstUser.poolPosition = 0;
        
        addTransaction(firstUser.id, 'credit', payoutAfterCharges, `Pool payout received (after charges: ₦${formatCurrency(chargesAmount)})`);
        
        // Send notification
        sendNotification(firstUser.email, `Congratulations! You received ₦${formatCurrency(payoutAfterCharges)} from Global Count Trading`);
    }
    
    // Add charges to admin balance
    systemData.adminBalance += chargesAmount;
    systemData.totalCharges += chargesAmount;
    systemData.totalRevenue += chargesAmount;
    
    // Add transaction for charges
    addTransaction('admin', 'credit', chargesAmount, 'Charges from pool completion');
    
    // Mark other users as ready for reinvestment
    pool.members.slice(1).forEach(member => {
        const user = systemData.users.find(u => u.id === member.userId);
        if (user) {
            user.currentPool = null;
            user.poolPosition = 0;
        }
    });
    
    saveToStorage();
    updateUI();
}

function notifyPoolMembers(pool) {
    const progress = (pool.members.length / 11) * 100;
    
    pool.members.forEach(member => {
        const user = systemData.users.find(u => u.id === member.userId);
        if (user && user.notificationSettings.pool) {
            sendNotification(user.email, `Pool update: ${pool.members.length}/11 members joined (${progress.toFixed(0)}%)`);
        }
    });
}

function updatePoolDisplay() {
    const user = getCurrentUserData();
    
    if (!user.currentPool) {
        document.getElementById('poolProgressBar').style.width = '0%';
        document.getElementById('poolProgressText').textContent = '0';
        document.getElementById('poolPlanAmount').textContent = '0.00';
        document.getElementById('yourPosition').textContent = '-';
        document.getElementById('membersJoined').textContent = '0/11';
        document.getElementById('payoutAmount').textContent = '0.00';
        document.getElementById('payoutAfterCharges').textContent = '0.00';
        document.getElementById('poolMembers').innerHTML = '<p>You are not currently in a pool. Select an investment plan to join.</p>';
        return;
    }
    
    const pool = systemData.pools.find(p => p.id === user.currentPool);
    if (!pool) return;
    
    const progress = (pool.members.length / 11) * 100;
    const payoutAmount = pool.amount * 10;
    const payoutAfterCharges = payoutAmount - charges.total;
    
    document.getElementById('poolProgressBar').style.width = progress + '%';
    document.getElementById('poolProgressText').textContent = pool.members.length;
    document.getElementById('poolPlanAmount').textContent = formatCurrency(pool.amount);
    document.getElementById('yourPosition').textContent = user.poolPosition;
    document.getElementById('membersJoined').textContent = `${pool.members.length}/11`;
    document.getElementById('payoutAmount').textContent = formatCurrency(payoutAmount);
    document.getElementById('payoutAfterCharges').textContent = formatCurrency(payoutAfterCharges);
    document.getElementById('estimatedPayout').textContent = formatCurrency(payoutAfterCharges);
    
    // Render pool members
    document.getElementById('poolMembers').innerHTML = pool.members.map((member, index) => {
        const isActive = member.userId === user.id;
        return `
            <div class="pool-member ${isActive ? 'active' : ''}">
                <div class="position">${index + 1}</div>
                <div class="name">${member.name}</div>
                <div class="date">${new Date(member.joinDate).toLocaleDateString()}</div>
            </div>
        `;
    }).join('');
    
    // Render pool chat
    updatePoolChat(pool);
}

function updatePoolChat(pool) {
    const chatContainer = document.getElementById('poolChat');
    
    const messages = [
        { time: pool.createdDate, message: `Pool created with ₦${formatCurrency(pool.amount)} plan` }
    ];
    
    pool.members.forEach((member, index) => {
        messages.push({
            time: member.joinDate,
            message: `${member.name} joined at position ${index + 1}`
        });
    });
    
    chatContainer.innerHTML = messages.map(msg => `
        <div class="chat-message">
            <div class="time">${new Date(msg.time).toLocaleString()}</div>
            <div class="message">${msg.message}</div>
        </div>
    `).join('');
}

// ==================== WALLET & TRANSACTIONS ====================
function selectDepositMethod(method) {
    document.querySelectorAll('.method-card').forEach(card => card.classList.remove('active'));
    event.target.closest('.method-card').classList.add('active');
    
    document.getElementById('bankDeposit').style.display = method === 'bank' ? 'block' : 'none';
    document.getElementById('cardDeposit').style.display = method === 'card' ? 'block' : 'none';
    document.getElementById('cryptoDeposit').style.display = method === 'crypto' ? 'block' : 'none';
}

function processDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    const receipt = document.getElementById('depositReceipt').files[0];
    const reference = document.getElementById('depositReference').value;
    const message = document.getElementById('depositMessage').value;
    
    if (!amount || amount < 1000) {
        showNotification('Minimum deposit is ₦1,000', 'error');
        return;
    }
    
    if (!receipt) {
        showNotification('Please upload payment receipt', 'error');
        return;
    }
    
    const user = getCurrentUserData();
    
    // Add to pending deposits
    systemData.pendingDeposits = systemData.pendingDeposits || [];
    systemData.pendingDeposits.push({
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        amount: amount,
        receipt: receipt.name,
        reference: reference,
        message: message,
        date: new Date().toISOString(),
        status: 'pending'
    });
    
    saveToStorage();
    
    showNotification('Deposit submitted for verification. You will be notified when approved.', 'success');
    
    // Send message to admin
    addMessage(user.id, `Deposit request: ₦${formatCurrency(amount)} - Receipt uploaded`);
}

function processCardPayment() {
    const amount = parseFloat(document.getElementById('cardDepositAmount').value);
    const cardNumber = document.getElementById('cardNumber').value;
    const expiry = document.getElementById('cardExpiry').value;
    const cvv = document.getElementById('cardCvv').value;
    const holder = document.getElementById('cardHolder').value;
    
    if (!amount || amount < 1000) {
        showNotification('Minimum deposit is ₦1,000', 'error');
        return;
    }
    
    if (!cardNumber || !expiry || !cvv || !holder) {
        showNotification('Please fill all card details', 'error');
        return;
    }
    
    // Simulate payment processing
    showNotification('Processing payment...', 'info');
    
    setTimeout(() => {
        const user = getCurrentUserData();
        user.balance += amount;
        
        addTransaction(user.id, 'credit', amount, `Card payment: ${cardNumber}`);
        
        saveToStorage();
        updateUI();
        
        showNotification(`₦${formatCurrency(amount)} successfully added to your wallet!`, 'success');
    }, 2000);
}

function processCryptoDeposit() {
    const amount = parseFloat(document.getElementById('cryptoAmountUSD').value);
    const cryptoType = document.getElementById('cryptoType').value;
    const txHash = document.getElementById('cryptoTxHash').value;
    
    if (!amount || amount < 1) {
        showNotification('Minimum deposit is $1 USD', 'error');
        return;
    }
    
    if (!txHash) {
        showNotification('Please provide transaction hash', 'error');
        return;
    }
    
    // Convert to NGN (assuming ₦1550 per $1)
    const ngnAmount = amount * 1550;
    
    const user = getCurrentUserData();
    
    // Add to pending deposits
    systemData.pendingDeposits = systemData.pendingDeposits || [];
    systemData.pendingDeposits.push({
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        amount: ngnAmount,
        cryptoType: cryptoType,
        usdAmount: amount,
        txHash: txHash,
        date: new Date().toISOString(),
        status: 'pending'
    });
    
    saveToStorage();
    
    showNotification('Crypto deposit submitted for verification.', 'success');
}

function calculateWithdrawalFee() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    const fee = amount * 0.02; // 2% withdrawal fee
    const receiveAmount = amount - fee;
    
    document.getElementById('withdrawFee').textContent = '₦' + formatCurrency(fee);
    document.getElementById('withdrawReceiveAmount').textContent = '₦' + formatCurrency(receiveAmount);
}

function processWithdrawal() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const bank = document.getElementById('withdrawBank').value;
    const accountNumber = document.getElementById('withdrawAccountNumber').value;
    const accountName = document.getElementById('withdrawAccountName').value;
    const phone = document.getElementById('withdrawPhoneNumber').value;
    
    if (!amount || amount < 1000) {
        showNotification('Minimum withdrawal is ₦1,000', 'error');
        return;
    }
    
    if (!bank || !accountNumber || !accountName || !phone) {
        showNotification('Please fill all bank details', 'error');
        return;
    }
    
    const user = getCurrentUserData();
    
    if (user.balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    // Deduct from balance
    user.balance -= amount;
    
    // Add to pending withdrawals
    systemData.pendingWithdrawals = systemData.pendingWithdrawals || [];
    systemData.pendingWithdrawals.push({
        id: Date.now(),
        userId: user.id,
        userName: user.name,
        amount: amount,
        bank: bank,
        accountNumber: accountNumber,
        accountName: accountName,
        phone: phone,
        date: new Date().toISOString(),
        status: 'pending'
    });
    
    addTransaction(user.id, 'debit', amount, `Withdrawal request to ${bank}`);
    
    saveToStorage();
    updateUI();
    
    showNotification('Withdrawal request submitted. You will be notified when processed.', 'success');
}

function viewTransactionHistory() {
    showNotification('Full transaction history coming soon', 'info');
}

// ==================== ADMIN FUNCTIONS ====================
function renderUsersList() {
    const container = document.getElementById('usersList');
    const users = systemData.users;
    
    if (users.length === 0) {
        container.innerHTML = '<p>No users registered yet</p>';
        return;
    }
    
    container.innerHTML = users.map(user => `
        <div class="user-card">
            <div class="user-info">
                <h4>${user.name}</h4>
                <p>Email: ${user.email}</p>
                <p>Phone: ${user.phone}</p>
                <p>Balance: ₦${formatCurrency(user.balance)}</p>
                <p>Status: <span class="${user.status === 'active' ? 'profit' : user.status === 'blocked' ? 'loss' : ''}">${user.status}</span></p>
            </div>
            <div class="user-actions">
                <button class="btn-info" onclick="viewUserDetails(${user.id})">Details</button>
                ${user.status === 'active' ? 
                    `<button class="btn-danger" onclick="blockUser(${user.id})">Block</button>` :
                    `<button class="btn-success" onclick="unblockUser(${user.id})">Unblock</button>`
                }
                <button class="btn-primary" onclick="editUserBalance(${user.id})">Edit Balance</button>
            </div>
        </div>
    `).join('');
}

function filterUsers() {
    const search = document.getElementById('userSearch').value.toLowerCase();
    const status = document.getElementById('userStatusFilter').value;
    
    let filtered = systemData.users;
    
    if (search) {
        filtered = filtered.filter(u => 
            u.name.toLowerCase().includes(search) || 
            u.email.toLowerCase().includes(search)
        );
    }
    
    if (status !== 'all') {
        filtered = filtered.filter(u => u.status === status);
    }
    
    // Re-render with filtered users
    // (Simplified - in production, would update the display)
}

function viewUserDetails(userId) {
    const user = systemData.users.find(u => u.id === userId);
    if (!user) return;
    
    const details = `
        <strong>${user.name}</strong><br>
        Email: ${user.email}<br>
        Phone: ${user.phone}<br>
        Address: ${user.address}<br>
        Balance: ₦${formatCurrency(user.balance)}<br>
        Invested: ₦${formatCurrency(user.invested)}<br>
        Earnings: ₦${formatCurrency(user.earnings)}<br>
        Status: ${user.status}<br>
        Contributions: ${user.contributions}<br>
        Payouts: ${user.payouts}<br>
        Join Date: ${new Date(user.joinDate).toLocaleDateString()}
    `;
    
    showNotification(details, 'info');
}

function blockUser(userId) {
    const user = systemData.users.find(u => u.id === userId);
    if (user) {
        user.status = 'blocked';
        saveToStorage();
        renderUsersList();
        showNotification(`${user.name} has been blocked`, 'success');
    }
}

function unblockUser(userId) {
    const user = systemData.users.find(u => u.id === userId);
    if (user) {
        user.status = 'active';
        saveToStorage();
        renderUsersList();
        showNotification(`${user.name} has been unblocked`, 'success');
    }
}

function editUserBalance(userId) {
    const user = systemData.users.find(u => u.id === userId);
    if (!user) return;
    
    const newBalance = prompt(`Current balance: ₦${formatCurrency(user.balance)}\nEnter new balance:`);
    
    if (newBalance !== null) {
        const amount = parseFloat(newBalance);
        if (!isNaN(amount)) {
            const difference = amount - user.balance;
            user.balance = amount;
            
            addTransaction(userId, difference >= 0 ? 'credit' : 'debit', Math.abs(difference), 'Balance adjusted by admin');
            
            saveToStorage();
            renderUsersList();
            showNotification(`${user.name}'s balance updated to ₦${formatCurrency(amount)}`, 'success');
        }
    }
}

function renderPendingApprovals() {
    // Pending registrations
    const pendingRegs = document.getElementById('pendingRegistrations');
    if (systemData.pendingRegistrations) {
        pendingRegs.innerHTML = systemData.pendingRegistrations.map(reg => {
            const user = systemData.users.find(u => u.id === reg.userId);
            if (!user) return '';
            
            return `
                <div class="user-card">
                    <div class="user-info">
                        <h4>${user.name}</h4>
                        <p>Email: ${user.email}</p>
                        <p>Phone: ${user.phone}</p>
                        <p>Passport: ${user.passport || 'Not uploaded'}</p>
                    </div>
                    <div class="user-actions">
                        <button class="btn-success" onclick="approveRegistration(${reg.id})">Approve</button>
                        <button class="btn-danger" onclick="rejectRegistration(${reg.id})">Reject</button>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    // Pending deposits and withdrawals would be rendered similarly
}

function approveRegistration(regId) {
    const regIndex = systemData.pendingRegistrations.findIndex(r => r.id === regId);
    if (regIndex === -1) return;
    
    const reg = systemData.pendingRegistrations[regIndex];
    const user = systemData.users.find(u => u.id === reg.userId);
    
    if (user) {
        user.status = 'active';
        sendNotification(user.email, 'Your account has been approved! You can now login.');
    }
    
    systemData.pendingRegistrations.splice(regIndex, 1);
    saveToStorage();
    renderPendingApprovals();
    
    showNotification('Registration approved', 'success');
}

function rejectRegistration(regId) {
    const regIndex = systemData.pendingRegistrations.findIndex(r => r.id === regId);
    if (regIndex === -1) return;
    
    const reg = systemData.pendingRegistrations[regIndex];
    const user = systemData.users.find(u => u.id === reg.userId);
    
    if (user) {
        user.status = 'blocked';
        sendNotification(user.email, 'Your registration has been rejected. Contact support for more information.');
    }
    
    systemData.pendingRegistrations.splice(regIndex, 1);
    saveToStorage();
    renderPendingApprovals();
    
    showNotification('Registration rejected', 'success');
}

function showApprovalTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.approval-content').forEach(content => content.style.display = 'none');
    
    event.target.classList.add('active');
    document.getElementById(tabName + 'Tab').style.display = 'block';
}

function adminTransfer() {
    const bank = document.getElementById('adminBankSelect').value;
    const accountNumber = document.getElementById('adminAccountNumber').value;
    const accountName = document.getElementById('adminAccountName').value;
    const amount = parseFloat(document.getElementById('adminTransferAmount').value);
    
    if (!bank || !accountNumber || !accountName || !amount) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    if (amount > systemData.adminBalance) {
        showNotification('Insufficient admin balance', 'error');
        return;
    }
    
    systemData.adminBalance -= amount;
    
    addTransaction('admin', 'debit', amount, `Transfer to ${bank} - ${accountNumber}`);
    
    saveToStorage();
    updateUI();
    
    showNotification(`₦${formatCurrency(amount)} transferred successfully`, 'success');
}

// ==================== HELPER FUNCTIONS ====================
function getCurrentUserData() {
    if (!currentUser) return null;
    return systemData.users.find(u => u.email === currentUser.email);
}

function formatCurrency(amount) {
    return parseFloat(amount).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function addTransaction(userId, type, amount, description) {
    systemData.transactions.push({
        id: Date.now(),
        userId: userId,
        type: type,
        amount: amount,
        description: description,
        date: new Date().toISOString()
    });
}

function addMessage(userId, message) {
    systemData.messages = systemData.messages || [];
    systemData.messages.push({
        id: Date.now(),
        userId: userId,
        message: message,
        date: new Date().toISOString(),
        status: 'unread'
    });
}

function sendNotification(email, message) {
    // In production, this would send actual email/SMS
    console.log(`Notification to ${email}: ${message}`);
}

function updateCustomerActivity() {
    const user = getCurrentUserData();
    if (!user) return;
    
    const transactions = systemData.transactions.filter(t => t.userId === user.id).slice(0, 10);
    const container = document.getElementById('customerActivity');
    
    if (transactions.length === 0) {
        container.innerHTML = '<p>No recent activity</p>';
        return;
    }
    
    container.innerHTML = transactions.map(tx => `
        <div class="activity-item">
            <div class="activity-info">
                <div class="activity-type">${tx.description}</div>
                <div class="activity-date">${new Date(tx.date).toLocaleDateString()}</div>
            </div>
            <div class="activity-amount ${tx.type}">
                ${tx.type === 'credit' ? '+' : '-'}₦${formatCurrency(tx.amount)}
            </div>
        </div>
    `).join('');
}

function updateUI() {
    if (isAdmin) {
        showAdminDashboard();
    } else if (currentUser) {
        showCustomerDashboard();
    }
}

// ==================== STORAGE ====================
function saveToStorage() {
    localStorage.setItem('globalCountTrading', JSON.stringify(systemData));
    if (currentUser) {
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
}

function loadFromStorage() {
    const data = localStorage.getItem('globalCountTrading');
    if (data) {
        systemData = JSON.parse(data);
    }
}

// ==================== NOTIFICATIONS ====================
function showNotification(message, type = 'info') {
    const modal = document.getElementById('notificationModal');
    const modalMessage = document.getElementById('modalMessage');
    
    let bgColor = '#4facfe';
    if (type === 'success') bgColor = '#38ef7d';
    if (type === 'error') bgColor = '#f45c43';
    if (type === 'warning') bgColor = '#f093fb';
    
    modalMessage.innerHTML = `
        <div style="background: ${bgColor}; color: white; padding: 20px; border-radius: 10px; text-align: center;">
            <h3 style="margin-bottom: 10px;">${type.charAt(0).toUpperCase() + type.slice(1)}</h3>
            <p>${message}</p>
        </div>
    `;
    
    modal.style.display = 'block';
    
    setTimeout(() => {
        closeModal('notificationModal');
    }, 5000);
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('notificationModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// Profile functions
function editProfile() {
    showNotification('Profile editing coming soon', 'info');
}

function changePassword() {
    const newPassword = prompt('Enter new password:');
    if (newPassword) {
        const user = getCurrentUserData();
        user.password = newPassword;
        saveToStorage();
        showNotification('Password changed successfully', 'success');
    }
}

function saveNotificationSettings() {
    const user = getCurrentUserData();
    user.notificationSettings = {
        email: document.getElementById('emailNotif').checked,
        sms: document.getElementById('smsNotif').checked,
        pool: document.getElementById('poolNotif').checked,
        payout: document.getElementById('payoutNotif').checked
    };
    saveToStorage();
    showNotification('Notification settings saved', 'success');
}