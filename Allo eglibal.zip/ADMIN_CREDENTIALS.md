# 🎛️ Admin Login Credentials
## Global Trading Platforms - Unified Admin System

---

## 🔐 Unified Admin System
**Access All Platforms from One Dashboard**

### Master Admin Login
- **Email:** `admin@globaltrading.com`
- **Password:** `MasterAdmin@2024`
- **Access:** All platforms (Unified Dashboard)
- **Role:** Super Administrator

---

## 🎯 NinjaTech Enhanced Trading Admin

### Login Details
- **Email:** `admin@ninjatech.com`
- **Password:** `NinjaTech@2024`
- **Access:** NinjaTech Trading Platform Only
- **Role:** Platform Administrator

### Features
- MetaTrader 5 Integration
- MetaTrader 4 Integration
- Trading Account Management
- Micro Account Support
- Manual & Automatic Trading
- Trade Recommendations
- User Profile Management

---

## ⚽ Sports Betting & Casino Admin

### Login Details
- **Email:** `admin@sportsbetting.com`
- **Password:** `SportsBetting@2024`
- **Access:** Sports Betting & Casino Platform Only
- **Role:** Platform Administrator

### Features
- Sports Betting Management
- Casino Games Management
- Credit/Debit Account System
- Matrix Network Patterns
- Current Movement Calculations
- User Bet Management
- Payout Processing

---

## 👥 Global Count Trading Admin

### Login Details
- **Email:** `adeganglobal@gmail.com`
- **Password:** `admin123`
- **Access:** Global Count Trading Platform Only
- **Role:** Platform Administrator

### Features
- 11-Person Matrix Contribution System
- Investment Tier Management
- User Registration Approval
- Deposit/Withdrawal Processing
- Pool Completion Monitoring
- Automatic Payout System
- Balance Editing
- Transaction Monitoring

---

## 🌾 Global Commodity Market Admin

### Login Details
- **Email:** `admin@commoditymarket.com`
- **Password:** `CommodityMarket@2024`
- **Access:** Global Commodity Market Platform Only
- **Role:** Platform Administrator

### Features
- Commodity Price Management
- Market Simulation Control
- Planting Investment Management
- Harvest Processing
- Dynamic Pricing Adjustment
- Wallet Management
- Transaction Monitoring
- Portfolio Tracking

---

## 🔗 Platform Integration

### Unified Wallet System
All platforms are linked through the **Unified Wallet System**:

- **Unified Balance:** Total balance across all platforms
- **Platform-Specific Balances:** Individual balances for each platform
- **Cross-Platform Transfers:** Transfer funds between platforms
- **Transaction Fee:** 2% on all transfers
- **Transaction History:** Complete audit trail

### Admin Dashboard Access

1. **Unified Admin Dashboard:**
   - URL: `/unified-admin/index.html`
   - Access: All platforms from single dashboard
   - Features: Cross-platform transactions, unified reports, total balance tracking

2. **Individual Platform Admin:**
   - Each platform has its own admin panel
   - Accessible via platform-specific credentials
   - Features: Platform-specific management

---

## 📊 Platform Summary

| Platform | Admin Email | Password | Platform Code | Color |
|----------|-------------|----------|---------------|-------|
| Unified | admin@globaltrading.com | MasterAdmin@2024 | UNIFIED | #8b5cf6 |
| NinjaTech | admin@ninjatech.com | NinjaTech@2024 | NT | #8b5cf6 |
| Sports Betting | admin@sportsbetting.com | SportsBetting@2024 | SB | #f59e0b |
| Global Count | adeganglobal@gmail.com | admin123 | GC | #10b981 |
| Commodity | admin@commoditymarket.com | CommodityMarket@2024 | CM | #3b82f6 |

---

## 🚀 Quick Access

### File Structure
```
/workspace/
├── unified-admin/
│   ├── index.html              # Unified Admin Dashboard
│   ├── admin.css              # Admin Dashboard Styles
│   └── admin.js               # Admin Dashboard Logic
├── shared-components/
│   ├── css/
│   │   └── common.css         # Shared Styles
│   └── js/
│       ├── common.js          # Shared Utilities
│       └── wallet-system.js   # Unified Wallet System
├── ninjatech-enhanced-trading/
├── sports-betting-casino/
├── global-count-trading/
└── global-commodity-market/
```

### Access Links
- **Unified Admin:** `file:///workspace/unified-admin/index.html`
- **NinjaTech:** `file:///workspace/ninjatech-enhanced-trading/index.html`
- **Sports Betting:** `file:///workspace/sports-betting-casino/index.html`
- **Global Count:** `file:///workspace/global-count-trading/index.html`
- **Commodity Market:** `file:///workspace/global-commodity-market/index.html`

---

## 🔧 System Features

### Shared Components
1. **Common CSS (`common.css`)**
   - Consistent styling across all platforms
   - Responsive design
   - Dark theme
   - Utility classes

2. **Common JS (`common.js`)**
   - Currency formatting
   - Date/time formatting
   - Storage management
   - Notifications
   - Validation functions
   - Modal management

3. **Wallet System (`wallet-system.js`)**
   - Unified balance tracking
   - Cross-platform transfers
   - Transaction management
   - Fee calculation
   - Balance history

### Admin Features
1. **Unified Dashboard**
   - View all platforms at once
   - Cross-platform transactions
   - Unified reports
   - Total balance tracking
   - User management across platforms

2. **Platform-Specific Admin**
   - Individual platform management
   - Platform-specific features
   - Dedicated user management
   - Transaction monitoring

---

## 📝 Important Notes

### Security
- **Never share admin credentials publicly**
- **Change default passwords after first login**
- **Use strong, unique passwords**
- **Enable two-factor authentication (when available)**

### Platform Linking
- All platforms share the same wallet system
- Transfers between platforms are instant
- 2% fee applies to all transfers
- Transaction history is maintained across platforms

### Data Storage
- All data is stored in browser localStorage
- Each platform maintains its own data
- Unified wallet aggregates all platform data
- Clear cache to reset all data

---

## 🆘 Support

### Contact Information
**System Owner:** Olawale Abdul-Ganiyu Adeshina
- **Email:** adeganglobal@gmail.com
- **Phone:** +2349030277275
- **Location:** Ikeja, Lagos, Ogun State, Nigeria

### Troubleshooting
1. **Login Issues:** Verify email and password
2. **Balance Issues:** Check wallet history
3. **Transfer Issues:** Ensure sufficient balance
4. **Platform Issues:** Clear browser cache

---

## 📅 Version History

### Version 1.0 (Current)
- ✅ Unified Admin System
- ✅ Shared Components
- ✅ Wallet Integration
- ✅ Cross-Platform Transfers
- ✅ Individual Platform Admin Panels

---

**Last Updated:** 2024
**System Version:** 1.0.0
**Platform Status:** All Systems Operational