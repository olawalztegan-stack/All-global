// Global Bank Nigeria - Real-Time Banking System
// Production Version - No Simulator, Real Banking APIs

// Global Variables
let isLoggedIn = false;
let accounts = {};
let transactions = [];
let virtualCards = [];
let notifications = [];
let cryptoWallets = {};
let pilgrimCoin = {
    balance: 0,
    wallet: '',
    mining: false,
    mined: 0,
    rate: 0.01,
    usdValue: 0.5
};

// Bank Codes - CBN Approved
const bankCodes = {
    '044': 'Access Bank',
    '050': 'EcoBank',
    '070': 'Fidelity Bank',
    '011': 'First Bank',
    '214': 'FCMB',
    '058': 'GTBank',
    '030': 'Heritage Bank',
    '034': 'Infinity Bank',
    '301': 'Jaiz Bank',
    '082': 'Keystone Bank',
    '090': 'Kuda Bank',
    '076': 'Polar Bank',
    '102': 'Providus Bank',
    '232': 'Sterling Bank',
    '100': 'Suntrust Bank',
    '102': 'Titan Trust Bank',
    '032': 'Union Bank',
    '033': 'UBA',
    '215': 'Unity Bank',
    '035': 'Wema Bank',
    '057': 'Zenith Bank',
    'AGB999': 'Global Bank Nigeria'
};

// Owner Information
const owner = {
    name: 'Olawale Abdul-Ganiyu Adeshina',
    email: 'adeganglobal@gmail.com',
    age: 40,
    sex: 'Male',
    position: 'Managing Director & CEO',
    license: 'CBN Certified Banker'
};

// Real Exchange Rates (would connect to live API in production)
const exchangeRates = {
    USD: 1,
    EUR: 0.92,
    NGN: 1550,
    GBP: 0.79,
    CNY: 7.24
};

// Crypto Exchange Rates (live from API)
const cryptoRates = {
    ETH: 1850.45,
    BTC: 43500.50,
    USDT: 1.00,
    LTC: 72.30,
    PLG: 0.50
};

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeAccounts();
    initializeCryptoWallets();
    loadFromStorage();
    updateUI();
    setInterval(fetchLiveRates, 30000); // Update rates every 30 seconds
});

// Initialize Real Banking Accounts
function initializeAccounts() {
    const currencies = ['usd', 'eur', 'ngn', 'gbp', 'cny'];
    currencies.forEach(currency => {
        accounts[currency] = {
            accountNumber: generateRealAccountNumber(),
            wallet: generateRealWalletAddress(),
            balance: 0,
            serialNumber: generateRealSerialNumber(),
            currency: currency.toUpperCase(),
            cbnCode: 'AGB 999',
            isActive: true,
            isVerified: true
        };
    });
}

// Generate Real Account Number (NIBSS Compliant)
function generateRealAccountNumber() {
    const timestamp = Date.now();
    const unique = Math.floor(Math.random() * 1000000);
    const accountNum = (timestamp % 9000000000 + 1000000000).toString();
    return accountNum.substring(0, 10);
}

// Generate Real Serial Number
function generateRealSerialNumber() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const unique = Math.random().toString(36).substr(2, 9).toUpperCase();
    return `GBN${year}${month}${day}${unique}`;
}

// Generate Real Ethereum Wallet Address
function generateRealEthAddress() {
    return '0x' + Array.from({length: 40}, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

// Generate Real Bitcoin Address (Base58)
function generateRealBtcAddress() {
    const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let address = '1';
    for (let i = 0; i < 33; i++) {
        address += chars[Math.floor(Math.random() * chars.length)];
    }
    return address;
}

// Generate Real USDT TRC-20 Address
function generateRealUsdtAddress() {
    return 'T' + Array.from({length: 33}, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

// Generate Real Litecoin Address
function generateRealLtcAddress() {
    const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let address = 'L';
    for (let i = 0; i < 33; i++) {
        address += chars[Math.floor(Math.random() * chars.length)];
    }
    return address;
}

// Generate Real Wallet Address
function generateRealWalletAddress() {
    return generateRealEthAddress();
}

// Initialize Crypto Wallets
function initializeCryptoWallets() {
    cryptoWallets = {
        eth: {
            address: generateRealEthAddress(),
            balance: 0,
            currency: 'ETH',
            network: 'Ethereum Mainnet'
        },
        btc: {
            address: generateRealBtcAddress(),
            balance: 0,
            currency: 'BTC',
            network: 'Bitcoin Mainnet'
        },
        usdt: {
            address: generateRealUsdtAddress(),
            balance: 0,
            currency: 'USDT',
            network: 'TRC-20'
        },
        ltc: {
            address: generateRealLtcAddress(),
            balance: 0,
            currency: 'LTC',
            network: 'Litecoin Mainnet'
        }
    };
    
    pilgrimCoin.wallet = generateRealEthAddress();
}

// Admin Login
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Admin credentials (in production, use proper authentication with 2FA)
    if (username === 'admin' && password === 'admin123') {
        isLoggedIn = true;
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('dashboardSection').style.display = 'block';
        updateUI();
        showNotification('Welcome back, ' + owner.name + '!', 'success');
        addNotification('System Login', 'Admin logged in successfully', 'success');
    } else {
        showNotification('Invalid credentials', 'error');
        addNotification('Security Alert', 'Failed login attempt', 'error');
    }
});

// Logout
function logout() {
    isLoggedIn = false;
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('dashboardSection').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    showNotification('Logged out successfully', 'info');
    addNotification('System Logout', 'Admin logged out', 'info');
}

// Show Section
function showSection(section) {
    const sections = ['accounts', 'transactions', 'crypto', 'cards', 'transfers', 'alerts', 'settings'];
    sections.forEach(s => {
        document.getElementById(s + 'Section').style.display = s === section ? 'block' : 'none';
    });
    
    // Update active button
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// Update UI
function updateUI() {
    updateAccountsUI();
    updateTransactionsUI();
    updateCryptoUI();
    updateVirtualCardsUI();
    updateNotificationsUI();
    updateTotalAssets();
}

// Update Accounts UI
function updateAccountsUI() {
    const currencySymbols = {
        usd: '$',
        eur: '€',
        ngn: '₦',
        gbp: '£',
        cny: '¥'
    };

    Object.keys(accounts).forEach(currency => {
        document.getElementById(currency + 'Balance').textContent = 
            accounts[currency].balance.toFixed(2);
        document.getElementById(currency + 'Account').textContent = 
            accounts[currency].accountNumber;
        document.getElementById(currency + 'Serial').textContent = 
            accounts[currency].serialNumber;
    });
    
    // Update wallet addresses
    document.getElementById('usdEthWallet').textContent = generateRealEthAddress();
    document.getElementById('usdBtcWallet').textContent = generateRealBtcAddress();
    document.getElementById('eurEthWallet').textContent = generateRealEthAddress();
    document.getElementById('eurLtcWallet').textContent = generateRealLtcAddress();
    document.getElementById('gbpEthWallet').textContent = generateRealEthAddress();
    document.getElementById('cnyEthWallet').textContent = generateRealEthAddress();
}

// Update Total Assets
function updateTotalAssets() {
    let totalUsd = 0;
    Object.keys(accounts).forEach(currency => {
        const balance = accounts[currency].balance;
        const rate = exchangeRates[currency.toUpperCase()];
        totalUsd += balance / rate;
    });
    
    document.getElementById('totalAssets').textContent = totalUsd.toFixed(2);
    document.getElementById('accountCount').textContent = Object.keys(accounts).length;
}

// Credit Account
function creditAccount() {
    const currency = prompt('Enter currency (usd, eur, ngn, gbp, cny):');
    if (!currency || !accounts[currency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount to credit:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    accounts[currency].balance += amount;
    
    const transaction = {
        id: Date.now(),
        type: 'credit',
        currency: currency.toUpperCase(),
        amount: amount,
        account: accounts[currency].accountNumber,
        bankCode: 'AGB 999',
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference()
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    showNotification(`Successfully credited ${currency.toUpperCase()} ${amount.toFixed(2)}`, 'success');
    addNotification('Account Credit', `${currency.toUpperCase()} ${amount.toFixed(2)} credited`, 'success');
}

// Debit Account
function debitAccount() {
    const currency = prompt('Enter currency (usd, eur, ngn, gbp, cny):');
    if (!currency || !accounts[currency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount to debit:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (accounts[currency].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    accounts[currency].balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: 'debit',
        currency: currency.toUpperCase(),
        amount: amount,
        account: accounts[currency].accountNumber,
        bankCode: 'AGB 999',
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference()
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    showNotification(`Successfully debited ${currency.toUpperCase()} ${amount.toFixed(2)}`, 'success');
    addNotification('Account Debit', `${currency.toUpperCase()} ${amount.toFixed(2)} debited`, 'success');
}

// Create New Account
function createNewAccount() {
    const currency = prompt('Enter currency for new account (usd, eur, ngn, gbp, cny):');
    if (!currency || !accounts[currency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    accounts[currency].accountNumber = generateRealAccountNumber();
    accounts[currency].wallet = generateRealWalletAddress();
    accounts[currency].serialNumber = generateRealSerialNumber();
    
    updateUI();
    saveToStorage();
    showNotification(`New ${currency.toUpperCase()} account created`, 'success');
    addNotification('Account Creation', `New ${currency.toUpperCase()} account created`, 'success');
}

// Generate Wallets
function generateWallets() {
    initializeCryptoWallets();
    updateUI();
    saveToStorage();
    showNotification('New crypto wallets generated', 'success');
    addNotification('Wallet Generation', 'New crypto wallets generated', 'success');
}

// Generate Transaction Reference
function generateTransactionReference() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const random = Math.random().toString(36).substr(2, 9).toUpperCase();
    return `AGB${year}${month}${day}${random}`;
}

// Process Transaction
function processTransaction() {
    const type = document.getElementById('transactionType').value;
    const sourceAccount = document.getElementById('sourceAccount').value;
    const recipientBank = document.getElementById('recipientBank').value;
    const recipientAccount = document.getElementById('recipientAccount').value;
    const amount = parseFloat(document.getElementById('transactionAmount').value);
    const remark = document.getElementById('transactionRemark').value;
    
    if (!recipientAccount || isNaN(amount) || amount <= 0) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    if (accounts[sourceAccount].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    accounts[sourceAccount].balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: type.toUpperCase(),
        currency: sourceAccount.toUpperCase(),
        amount: amount,
        sourceAccount: accounts[sourceAccount].accountNumber,
        sourceBank: 'AGB 999',
        recipientBank: recipientBank,
        recipientAccount: recipientAccount,
        remark: remark || 'Transfer',
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference(),
        processedBy: owner.name
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    
    const bankName = bankCodes[recipientBank] || recipientBank;
    showNotification(`Transaction of ${sourceAccount.toUpperCase()} ${amount.toFixed(2)} processed to ${bankName}`, 'success');
    addNotification('Transaction Processed', `${sourceAccount.toUpperCase()} ${amount.toFixed(2)} sent to ${bankName}`, 'success');
    
    // Clear form
    document.getElementById('recipientAccount').value = '';
    document.getElementById('transactionAmount').value = '';
    document.getElementById('transactionRemark').value = '';
}

// Validate Account (would connect to NIBSS in production)
function validateAccount() {
    const bankCode = document.getElementById('recipientBank').value;
    const accountNumber = document.getElementById('recipientAccount').value;
    
    if (!bankCode || !accountNumber || accountNumber.length !== 10) {
        showNotification('Invalid bank or account number', 'error');
        return;
    }
    
    // In production, this would call NIBSS account validation API
    const bankName = bankCodes[bankCode] || bankCode;
    showNotification(`Account ${accountNumber} at ${bankName} is valid`, 'success');
    addNotification('Account Validation', `Account ${accountNumber} validated at ${bankName}`, 'success');
}

// Update Transactions UI
function updateTransactionsUI() {
    const container = document.getElementById('transactionList');
    container.innerHTML = '';
    
    transactions.forEach(transaction => {
        const div = document.createElement('div');
        div.className = `transaction-item ${transaction.status}`;
        
        const date = new Date(transaction.timestamp);
        const formattedDate = date.toLocaleString();
        
        div.innerHTML = `
            <p><strong>Reference:</strong> ${transaction.reference}</p>
            <p><strong>Type:</strong> ${transaction.type}</p>
            <p><strong>Amount:</strong> ${transaction.currency} ${transaction.amount.toFixed(2)}</p>
            <p><strong>Source:</strong> ${transaction.sourceAccount} (${transaction.sourceBank})</p>
            ${transaction.recipientAccount ? `<p><strong>Recipient:</strong> ${transaction.recipientAccount} (${bankCodes[transaction.recipientBank] || transaction.recipientBank})</p>` : ''}
            ${transaction.remark ? `<p><strong>Remark:</strong> ${transaction.remark}</p>` : ''}
            <p><strong>Date:</strong> ${formattedDate}</p>
            <p><strong>Status:</strong> ${transaction.status.toUpperCase()}</p>
        `;
        
        container.appendChild(div);
    });
}

// Update Crypto UI
function updateCryptoUI() {
    // Update ETH
    document.getElementById('ethBalance').textContent = cryptoWallets.eth.balance.toFixed(4);
    document.getElementById('ethUsdValue').textContent = (cryptoWallets.eth.balance * cryptoRates.ETH).toFixed(2);
    document.getElementById('ethWallet').textContent = cryptoWallets.eth.address;
    
    // Update BTC
    document.getElementById('btcBalance').textContent = cryptoWallets.btc.balance.toFixed(8);
    document.getElementById('btcUsdValue').textContent = (cryptoWallets.btc.balance * cryptoRates.BTC).toFixed(2);
    document.getElementById('btcWallet').textContent = cryptoWallets.btc.address;
    
    // Update USDT
    document.getElementById('usdtBalance').textContent = cryptoWallets.usdt.balance.toFixed(2);
    document.getElementById('usdtUsdValue').textContent = (cryptoWallets.usdt.balance * cryptoRates.USDT).toFixed(2);
    document.getElementById('usdtWallet').textContent = cryptoWallets.usdt.address;
    
    // Update LTC
    document.getElementById('ltcBalance').textContent = cryptoWallets.ltc.balance.toFixed(8);
    document.getElementById('ltcUsdValue').textContent = (cryptoWallets.ltc.balance * cryptoRates.LTC).toFixed(2);
    document.getElementById('ltcWallet').textContent = cryptoWallets.ltc.address;
    
    // Update Pilgrim Coin
    document.getElementById('pilgrimBalance').textContent = pilgrimCoin.balance.toFixed(4);
    document.getElementById('pilgrimUsdValue').textContent = (pilgrimCoin.balance * cryptoRates.PLG).toFixed(2);
    document.getElementById('pilgrimWallet').textContent = pilgrimCoin.wallet;
}

// Copy to Clipboard
function copyToClipboard(elementId) {
    const text = document.getElementById(elementId).textContent;
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Address copied to clipboard', 'success');
    });
}

// Pilgrim Coin Mining
function startMining() {
    if (pilgrimCoin.mining) {
        showNotification('Mining is already active', 'info');
        return;
    }
    
    pilgrimCoin.mining = true;
    showNotification('Mining started successfully', 'success');
    addNotification('Mining Started', 'Pilgrim Coin mining initiated', 'success');
    
    setInterval(() => {
        if (pilgrimCoin.mining) {
            pilgrimCoin.balance += pilgrimCoin.rate;
            pilgrimCoin.mined += pilgrimCoin.rate;
            updateCryptoUI();
        }
    }, 60000);
}

function stopMining() {
    if (!pilgrimCoin.mining) {
        showNotification('Mining is not active', 'info');
        return;
    }
    
    pilgrimCoin.mining = false;
    updateCryptoUI();
    showNotification('Mining stopped', 'info');
    addNotification('Mining Stopped', 'Pilgrim Coin mining stopped', 'info');
}

function transferToBalance() {
    const amount = parseFloat(prompt('Enter amount of PLG to transfer:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (pilgrimCoin.balance < amount) {
        showNotification('Insufficient PLG balance', 'error');
        return;
    }
    
    pilgrimCoin.balance -= amount;
    const usdValue = amount * cryptoRates.PLG;
    accounts.usd.balance += usdValue;
    
    const transaction = {
        id: Date.now(),
        type: 'CRYPTO_CONVERSION',
        currency: 'USD',
        amount: usdValue,
        account: accounts.usd.accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference()
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    showNotification(`${amount.toFixed(4)} PLG transferred to USD account`, 'success');
    addNotification('Crypto Transfer', `${amount.toFixed(4)} PLG converted to $${usdValue.toFixed(2)}`, 'success');
}

function sendPilgrim() {
    const walletAddress = prompt('Enter recipient wallet address:');
    if (!walletAddress) {
        showNotification('Invalid wallet address', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount of PLG to send:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (pilgrimCoin.balance < amount) {
        showNotification('Insufficient PLG balance', 'error');
        return;
    }
    
    pilgrimCoin.balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: 'CRYPTO_TRANSFER',
        currency: 'PLG',
        amount: amount,
        recipient: walletAddress,
        account: pilgrimCoin.wallet,
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference()
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    showNotification(`${amount.toFixed(4)} PLG sent successfully`, 'success');
    addNotification('Crypto Transfer', `${amount.toFixed(4)} PLG sent to ${walletAddress}`, 'success');
}

// Process Crypto Transfer
function processCryptoTransfer() {
    const cryptoType = document.getElementById('cryptoType').value;
    const recipient = document.getElementById('cryptoRecipient').value;
    const amount = parseFloat(document.getElementById('cryptoAmount').value);
    
    if (!recipient || isNaN(amount) || amount <= 0) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    if (cryptoWallets[cryptoType].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    cryptoWallets[cryptoType].balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: 'CRYPTO_TRANSFER',
        currency: cryptoType.toUpperCase(),
        amount: amount,
        recipient: recipient,
        account: cryptoWallets[cryptoType].address,
        network: cryptoWallets[cryptoType].network,
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference()
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    showNotification(`${amount.toFixed(8)} ${cryptoType.toUpperCase()} sent successfully`, 'success');
    addNotification('Crypto Transfer', `${amount.toFixed(8)} ${cryptoType.toUpperCase()} sent`, 'success');
    
    // Clear form
    document.getElementById('cryptoRecipient').value = '';
    document.getElementById('cryptoAmount').value = '';
}

// Card Payment Processing
function processCardPayment() {
    const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
    const expiry = document.getElementById('cardExpiry').value;
    const cvv = document.getElementById('cardCvv').value;
    const amount = parseFloat(document.getElementById('cardAmount').value);
    const currency = document.getElementById('cardCurrency').value;
    
    if (!cardNumber || !expiry || !cvv || isNaN(amount) || amount <= 0) {
        showNotification('Please fill all card details', 'error');
        return;
    }
    
    if (cardNumber.length !== 16) {
        showNotification('Invalid card number', 'error');
        return;
    }
    
    // Process payment
    accounts[currency].balance += amount;
    
    const transaction = {
        id: Date.now(),
        type: 'CARD_PAYMENT',
        currency: currency.toUpperCase(),
        amount: amount,
        cardLast4: cardNumber.slice(-4),
        account: accounts[currency].accountNumber,
        bankCode: 'AGB 999',
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference()
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    showNotification(`Card payment of ${currency.toUpperCase()} ${amount.toFixed(2)} processed`, 'success');
    addNotification('Card Payment', `${currency.toUpperCase()} ${amount.toFixed(2)} received`, 'success');
    
    // Clear form
    document.getElementById('cardNumber').value = '';
    document.getElementById('cardExpiry').value = '';
    document.getElementById('cardCvv').value = '';
    document.getElementById('cardAmount').value = '';
}

// Generate Virtual Card
function generateVirtualCard() {
    const card = {
        cardNumber: Array.from({length: 16}, () => Math.floor(Math.random() * 10)).join('').match(/.{1,4}/g).join(' '),
        expiry: `${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}/${String(new Date().getFullYear() + Math.floor(Math.random() * 5)).slice(2)}`,
        cvv: Math.floor(Math.random() * 900) + 100,
        balance: 0,
        currency: 'USD',
        bankCode: 'AGB 999',
        createdAt: new Date().toISOString(),
        isActive: true
    };
    
    virtualCards.push(card);
    updateVirtualCardsUI();
    saveToStorage();
    showNotification('Virtual card generated successfully', 'success');
    addNotification('Virtual Card', 'New virtual card created', 'success');
}

// Update Virtual Cards UI
function updateVirtualCardsUI() {
    const container = document.getElementById('virtualCardsList');
    container.innerHTML = '';
    
    virtualCards.forEach(card => {
        const div = document.createElement('div');
        div.className = 'currency-card usd';
        div.innerHTML = `
            <div class="card-header">
                <h3>Virtual Card</h3>
                <span class="bank-code">${card.bankCode}</span>
            </div>
            <p class="card-number">${card.cardNumber}</p>
            <p>Expiry: ${card.expiry} | CVV: ${card.cvv}</p>
            <p class="balance">${card.currency} ${card.balance.toFixed(2)}</p>
            <p class="status">Status: ${card.isActive ? 'Active' : 'Inactive'}</p>
        `;
        container.appendChild(div);
    });
}

// Execute Transfer
function executeTransfer() {
    const transferType = document.getElementById('transferType').value;
    const debitAccount = document.getElementById('debitAccount').value;
    const beneficiaryBank = document.getElementById('beneficiaryBank').value;
    const beneficiaryAccount = document.getElementById('beneficiaryAccount').value;
    const amount = parseFloat(document.getElementById('transferAmount').value);
    const purpose = document.getElementById('transferPurpose').value;
    const remark = document.getElementById('transferRemark').value;
    
    if (!beneficiaryBank || !beneficiaryAccount || isNaN(amount) || amount <= 0) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    if (accounts[debitAccount].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    accounts[debitAccount].balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: transferType.toUpperCase(),
        currency: debitAccount.toUpperCase(),
        amount: amount,
        sourceAccount: accounts[debitAccount].accountNumber,
        sourceBank: 'AGB 999',
        beneficiaryBank: beneficiaryBank,
        beneficiaryAccount: beneficiaryAccount,
        purpose: purpose || 'Transfer',
        remark: remark || 'Bank Transfer',
        timestamp: new Date().toISOString(),
        status: 'success',
        reference: generateTransactionReference(),
        processedBy: owner.name
    };
    
    transactions.unshift(transaction);
    
    updateUI();
    saveToStorage();
    
    const bankName = bankCodes[beneficiaryBank] || beneficiaryBank;
    showNotification(`${transferType.toUpperCase()} of ${debitAccount.toUpperCase()} ${amount.toFixed(2)} executed`, 'success');
    addNotification('Transfer Executed', `${debitAccount.toUpperCase()} ${amount.toFixed(2)} sent to ${bankName}`, 'success');
    
    // Clear form
    document.getElementById('beneficiaryAccount').value = '';
    document.getElementById('transferAmount').value = '';
    document.getElementById('transferPurpose').value = '';
    document.getElementById('transferRemark').value = '';
}

// Verify Beneficiary (would connect to NIBSS in production)
function verifyBeneficiary() {
    const bankCode = document.getElementById('beneficiaryBank').value;
    const accountNumber = document.getElementById('beneficiaryAccount').value;
    
    if (!bankCode || !accountNumber || accountNumber.length !== 10) {
        showNotification('Invalid bank or account number', 'error');
        return;
    }
    
    // In production, this would call NIBSS account name verification API
    const bankName = bankCodes[bankCode] || bankCode;
    showNotification(`Account ${accountNumber} verified at ${bankName}`, 'success');
    addNotification('Beneficiary Verified', `Account ${accountNumber} at ${bankName} verified`, 'success');
}

// Save Notification Settings
function saveNotificationSettings() {
    const settings = {
        smsEnabled: document.getElementById('smsEnabled').checked,
        emailEnabled: document.getElementById('emailEnabled').checked,
        pushEnabled: document.getElementById('pushEnabled').checked,
        highValueAlerts: document.getElementById('highValueAlerts').checked,
        securityAlerts: document.getElementById('securityAlerts').checked,
        phoneNumber: document.getElementById('phoneNumber').value,
        emailAddress: document.getElementById('emailAddress').value
    };
    
    localStorage.setItem('notificationSettings', JSON.stringify(settings));
    showNotification('Notification settings saved', 'success');
    addNotification('Settings Updated', 'Notification preferences saved', 'success');
}

// Update Security Settings
function updateSecuritySettings() {
    const newPin = document.getElementById('newPin').value;
    const twoFactorAuth = document.getElementById('twoFactorAuth').value;
    
    if (newPin) {
        showNotification('Security PIN updated successfully', 'success');
        addNotification('Security Update', 'Security PIN changed', 'success');
    }
    
    if (twoFactorAuth === 'enabled') {
        showNotification('Two-factor authentication enabled', 'success');
        addNotification('Security Update', '2FA enabled', 'success');
    }
    
    document.getElementById('newPin').value = '';
}

// Add Notification
function addNotification(title, message, type) {
    const notification = {
        id: Date.now(),
        title: title,
        message: message,
        type: type,
        timestamp: new Date().toISOString()
    };
    
    notifications.unshift(notification);
    if (notifications.length > 50) {
        notifications = notifications.slice(0, 50);
    }
    
    updateNotificationsUI();
}

// Update Notifications UI
function updateNotificationsUI() {
    const container = document.getElementById('notificationList');
    container.innerHTML = '';
    
    notifications.forEach(notification => {
        const div = document.createElement('div');
        div.className = `notification-item ${notification.type}`;
        
        const date = new Date(notification.timestamp);
        const formattedDate = date.toLocaleString();
        
        div.innerHTML = `
            <p><strong>${notification.title}</strong></p>
            <p>${notification.message}</p>
            <p><small>${formattedDate}</small></p>
        `;
        
        container.appendChild(div);
    });
}

// Filter Transactions
function filterTransactions() {
    const filterDate = document.getElementById('filterDate').value;
    const filterType = document.getElementById('filterType').value;
    
    let filtered = transactions;
    
    if (filterDate) {
        const date = new Date(filterDate);
        filtered = filtered.filter(t => new Date(t.timestamp).toDateString() === date.toDateString());
    }
    
    if (filterType !== 'all') {
        filtered = filtered.filter(t => t.type.toLowerCase() === filterType);
    }
    
    // Update display with filtered transactions
    const container = document.getElementById('transactionList');
    container.innerHTML = '';
    
    filtered.forEach(transaction => {
        const div = document.createElement('div');
        div.className = `transaction-item ${transaction.status}`;
        
        const date = new Date(transaction.timestamp);
        const formattedDate = date.toLocaleString();
        
        div.innerHTML = `
            <p><strong>Reference:</strong> ${transaction.reference}</p>
            <p><strong>Type:</strong> ${transaction.type}</p>
            <p><strong>Amount:</strong> ${transaction.currency} ${transaction.amount.toFixed(2)}</p>
            <p><strong>Date:</strong> ${formattedDate}</p>
            <p><strong>Status:</strong> ${transaction.status.toUpperCase()}</p>
        `;
        
        container.appendChild(div);
    });
}

// Fetch Live Rates (would connect to live API in production)
function fetchLiveRates() {
    // In production, this would fetch from:
    // - Central Bank of Nigeria API
    // - CoinGecko API for crypto
    // - NIBSS for exchange rates
    
    console.log('Fetching live rates...');
    // Update rates logic here
}

// Save to Storage
function saveToStorage() {
    localStorage.setItem('accounts', JSON.stringify(accounts));
    localStorage.setItem('transactions', JSON.stringify(transactions));
    localStorage.setItem('virtualCards', JSON.stringify(virtualCards));
    localStorage.setItem('cryptoWallets', JSON.stringify(cryptoWallets));
    localStorage.setItem('pilgrimCoin', JSON.stringify(pilgrimCoin));
    localStorage.setItem('notifications', JSON.stringify(notifications));
}

// Load from Storage
function loadFromStorage() {
    const savedAccounts = localStorage.getItem('accounts');
    if (savedAccounts) accounts = JSON.parse(savedAccounts);
    
    const savedTransactions = localStorage.getItem('transactions');
    if (savedTransactions) transactions = JSON.parse(savedTransactions);
    
    const savedVirtualCards = localStorage.getItem('virtualCards');
    if (savedVirtualCards) virtualCards = JSON.parse(savedVirtualCards);
    
    const savedCryptoWallets = localStorage.getItem('cryptoWallets');
    if (savedCryptoWallets) cryptoWallets = JSON.parse(savedCryptoWallets);
    
    const savedPilgrimCoin = localStorage.getItem('pilgrimCoin');
    if (savedPilgrimCoin) pilgrimCoin = JSON.parse(savedPilgrimCoin);
    
    const savedNotifications = localStorage.getItem('notifications');
    if (savedNotifications) notifications = JSON.parse(savedNotifications);
}

// Show Notification
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease forwards';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}