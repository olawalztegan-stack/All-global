// Global Bank Nigeria - Complete Banking Application

// Global Variables
let isLoggedIn = false;
let accounts = {};
let transactions = [];
let pilgrimCoin = {
    balance: 0,
    wallet: '',
    mining: false,
    mined: 0,
    rate: 0.01,
    usdValue: 0.5
};
let virtualCards = [];
let alerts = [];
let miningInterval = null;
let robotInterval = null;

// Owner Information
const owner = {
    name: 'Olawale Abdul-Ganiyu Adeshina',
    email: 'adeganglobal@gmail.com',
    age: 40,
    sex: 'Male',
    position: 'Founder & CEO'
};

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeAccounts();
    initializePilgrimCoin();
    loadVirtualCards();
    loadTransactions();
    loadAlerts();
    updateUI();
});

// Initialize Accounts
function initializeAccounts() {
    const currencies = ['usd', 'eur', 'ngn', 'gbp', 'cny'];
    currencies.forEach(currency => {
        accounts[currency] = {
            accountNumber: generateAccountNumber(),
            wallet: generateWalletAddress(),
            balance: 0,
            serialNumber: generateSerialNumber()
        };
    });
}

// Generate Account Number (1-10 digits)
function generateAccountNumber() {
    const length = Math.floor(Math.random() * 10) + 1;
    let accountNumber = '';
    for (let i = 0; i < length; i++) {
        accountNumber += Math.floor(Math.random() * 10);
    }
    return accountNumber.padStart(10, '0').substring(0, 10);
}

// Generate Serial Number
function generateSerialNumber() {
    return 'GBN-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9).toUpperCase();
}

// Generate Blockchain Wallet Address
function generateWalletAddress() {
    return '0x' + Array.from({length: 40}, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

// Initialize Pilgrim Coin
function initializePilgrimCoin() {
    pilgrimCoin.wallet = generateWalletAddress();
}

// Login System
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Admin credentials (hardcoded for this demo)
    if (username === 'admin' && password === 'admin123') {
        isLoggedIn = true;
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('dashboardSection').style.display = 'block';
        updateUI();
        showNotification('Welcome back, ' + owner.name + '!', 'success');
    } else {
        showNotification('Invalid credentials', 'error');
    }
});

// Logout
function logout() {
    isLoggedIn = false;
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('dashboardSection').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    showNotification('Logged out successfully', 'info');
}

// Show Section
function showSection(section) {
    const sections = ['accounts', 'transactions', 'crypto', 'cards', 'alerts', 'server'];
    sections.forEach(s => {
        document.getElementById(s + 'Section').style.display = s === section ? 'block' : 'none';
    });
}

// Update UI
function updateUI() {
    updateAccountsUI();
    updateTransactionsUI();
    updatePilgrimCoinUI();
    updateVirtualCardsUI();
    updateAlertsUI();
    updateServerUI();
}

// Update Accounts UI
function updateAccountsUI() {
    const currencySymbols = {
        usd: '$',
        eur: '€',
        ngn: '₦',
        gbp: '£',
        cny: '¥'
    };

    Object.keys(accounts).forEach(currency => {
        document.getElementById(currency + 'Balance').textContent = accounts[currency].balance.toFixed(2);
        document.getElementById(currency + 'Account').textContent = accounts[currency].accountNumber;
        document.getElementById(currency + 'Wallet').textContent = accounts[currency].wallet;
    });
}

// Credit Account
function creditAccount() {
    const currency = prompt('Enter currency (usd, eur, ngn, gbp, cny):');
    if (!currency || !accounts[currency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount to credit:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    accounts[currency].balance += amount;
    addTransaction({
        type: 'credit',
        currency: currency,
        amount: amount,
        account: accounts[currency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    });
    
    updateUI();
    showNotification(`Successfully credited ${currency.toUpperCase()} ${amount.toFixed(2)}`, 'success');
    sendAlert(`Credit: ${currency.toUpperCase()} ${amount.toFixed(2)} added to account`);
}

// Debit Account
function debitAccount() {
    const currency = prompt('Enter currency (usd, eur, ngn, gbp, cny):');
    if (!currency || !accounts[currency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount to debit:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (accounts[currency].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    accounts[currency].balance -= amount;
    addTransaction({
        type: 'debit',
        currency: currency,
        amount: amount,
        account: accounts[currency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    });
    
    updateUI();
    showNotification(`Successfully debited ${currency.toUpperCase()} ${amount.toFixed(2)}`, 'success');
    sendAlert(`Debit: ${currency.toUpperCase()} ${amount.toFixed(2)} from account`);
}

// Transfer to Main Balance
function transferToMain() {
    const fromCurrency = prompt('Enter currency to transfer from (usd, eur, ngn, gbp, cny):');
    if (!fromCurrency || !accounts[fromCurrency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount to transfer:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (accounts[fromCurrency].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    accounts[fromCurrency].balance -= amount;
    // In a real system, this would convert and add to main balance
    // For demo, we'll just show success
    
    addTransaction({
        type: 'transfer_to_main',
        currency: fromCurrency,
        amount: amount,
        account: accounts[fromCurrency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    });
    
    updateUI();
    showNotification(`Successfully transferred ${fromCurrency.toUpperCase()} ${amount.toFixed(2)} to main balance`, 'success');
    sendAlert(`Transfer: ${fromCurrency.toUpperCase()} ${amount.toFixed(2)} transferred to main balance`);
}

// Generate New Account
function generateNewAccount() {
    const currency = prompt('Enter currency for new account (usd, eur, ngn, gbp, cny):');
    if (!currency || !accounts[currency]) {
        showNotification('Invalid currency', 'error');
        return;
    }
    
    accounts[currency].accountNumber = generateAccountNumber();
    accounts[currency].wallet = generateWalletAddress();
    accounts[currency].serialNumber = generateSerialNumber();
    
    updateUI();
    showNotification(`New ${currency.toUpperCase()} account generated successfully`, 'success');
    sendAlert(`New Account: ${currency.toUpperCase()} account created with number ${accounts[currency].accountNumber}`);
}

// Process Transaction
function processTransaction() {
    const currency = document.getElementById('transactionCurrency').value;
    const type = document.getElementById('transactionType').value;
    const recipient = document.getElementById('recipientAddress').value;
    const amount = parseFloat(document.getElementById('transactionAmount').value);
    const bankName = document.getElementById('bankName').value;
    
    if (!recipient || isNaN(amount) || amount <= 0) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    if (accounts[currency].balance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    accounts[currency].balance -= amount;
    
    const transaction = {
        type: type,
        currency: currency,
        amount: amount,
        recipient: recipient,
        bank: bankName,
        account: accounts[currency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    addTransaction(transaction);
    
    // Add "Global Bank Nigeria" to other banks' payment/receive lists
    if (type === 'transfer' && bankName !== 'Global Bank Nigeria') {
        addToBankLists(bankName, recipient);
    }
    
    updateUI();
    showNotification(`Transaction of ${currency.toUpperCase()} ${amount.toFixed(2)} processed successfully`, 'success');
    sendAlert(`Transaction: ${currency.toUpperCase()} ${amount.toFixed(2)} sent to ${recipient}`);
    
    // Clear form
    document.getElementById('recipientAddress').value = '';
    document.getElementById('transactionAmount').value = '';
}

// Add to Bank Lists
function addToBankLists(bankName, accountNumber) {
    // In a real system, this would communicate with other banks
    console.log(`Adding Global Bank Nigeria to ${bankName}'s payment/receive lists for account ${accountNumber}`);
    showNotification(`Global Bank Nigeria added to ${bankName}'s lists`, 'info');
}

// Add Transaction
function addTransaction(transaction) {
    transaction.id = Date.now();
    transactions.unshift(transaction);
    if (transactions.length > 100) {
        transactions = transactions.slice(0, 100);
    }
    saveTransactions();
}

// Update Transactions UI
function updateTransactionsUI() {
    const container = document.getElementById('transactionList');
    container.innerHTML = '';
    
    transactions.forEach(transaction => {
        const div = document.createElement('div');
        div.className = `transaction-item ${transaction.status}`;
        
        const date = new Date(transaction.timestamp);
        const formattedDate = date.toLocaleString();
        
        div.innerHTML = `
            <p><strong>Type:</strong> ${transaction.type.toUpperCase()}</p>
            <p><strong>Amount:</strong> ${transaction.currency.toUpperCase()} ${transaction.amount.toFixed(2)}</p>
            <p><strong>Account:</strong> ${transaction.account}</p>
            ${transaction.recipient ? `<p><strong>Recipient:</strong> ${transaction.recipient}</p>` : ''}
            ${transaction.bank ? `<p><strong>Bank:</strong> ${transaction.bank}</p>` : ''}
            <p><strong>Date:</strong> ${formattedDate}</p>
            <p><strong>Status:</strong> ${transaction.status.toUpperCase()}</p>
        `;
        
        container.appendChild(div);
    });
}

// Save/Load Transactions
function saveTransactions() {
    localStorage.setItem('transactions', JSON.stringify(transactions));
}

function loadTransactions() {
    const saved = localStorage.getItem('transactions');
    if (saved) {
        transactions = JSON.parse(saved);
    }
}

// Pilgrim Coin Functions
function updatePilgrimCoinUI() {
    document.getElementById('pilgrimBalance').textContent = pilgrimCoin.balance.toFixed(4);
    document.getElementById('pilgrimUsdValue').textContent = (pilgrimCoin.balance * pilgrimCoin.usdValue).toFixed(2);
    document.getElementById('pilgrimWallet').textContent = pilgrimCoin.wallet;
    document.getElementById('miningStatus').textContent = pilgrimCoin.mining ? 'Active' : 'Inactive';
    document.getElementById('miningRate').textContent = pilgrimCoin.rate.toFixed(4);
    document.getElementById('minedAmount').textContent = pilgrimCoin.mined.toFixed(4);
}

// Start Mining
function startMining() {
    if (pilgrimCoin.mining) {
        showNotification('Mining is already active', 'info');
        return;
    }
    
    pilgrimCoin.mining = true;
    miningInterval = setInterval(() => {
        pilgrimCoin.balance += pilgrimCoin.rate;
        pilgrimCoin.mined += pilgrimCoin.rate;
        updatePilgrimCoinUI();
    }, 60000); // Add coins every minute
    
    showNotification('Mining started successfully', 'success');
    sendAlert('Mining: Pilgrim Coin mining started');
}

// Stop Mining
function stopMining() {
    if (!pilgrimCoin.mining) {
        showNotification('Mining is not active', 'info');
        return;
    }
    
    pilgrimCoin.mining = false;
    clearInterval(miningInterval);
    updatePilgrimCoinUI();
    
    showNotification('Mining stopped', 'info');
    sendAlert('Mining: Pilgrim Coin mining stopped');
}

// Transfer to Balance
function transferToBalance() {
    const amount = parseFloat(prompt('Enter amount of Pilgrim Coin to transfer:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (pilgrimCoin.balance < amount) {
        showNotification('Insufficient Pilgrim Coin balance', 'error');
        return;
    }
    
    pilgrimCoin.balance -= amount;
    const usdValue = amount * pilgrimCoin.usdValue;
    accounts.usd.balance += usdValue;
    
    addTransaction({
        type: 'pilgrim_to_balance',
        currency: 'usd',
        amount: usdValue,
        account: accounts.usd.accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    });
    
    updateUI();
    showNotification(`Successfully transferred ${amount.toFixed(4)} PLG ($${usdValue.toFixed(2)}) to USD balance`, 'success');
    sendAlert(`Transfer: ${amount.toFixed(4)} PLG transferred to USD balance`);
}

// Send Pilgrim
function sendPilgrim() {
    const walletAddress = prompt('Enter recipient wallet address:');
    if (!walletAddress) {
        showNotification('Invalid wallet address', 'error');
        return;
    }
    
    const amount = parseFloat(prompt('Enter amount of Pilgrim Coin to send:'));
    if (isNaN(amount) || amount <= 0) {
        showNotification('Invalid amount', 'error');
        return;
    }
    
    if (pilgrimCoin.balance < amount) {
        showNotification('Insufficient Pilgrim Coin balance', 'error');
        return;
    }
    
    pilgrimCoin.balance -= amount;
    
    addTransaction({
        type: 'pilgrim_transfer',
        currency: 'plg',
        amount: amount,
        recipient: walletAddress,
        account: pilgrimCoin.wallet,
        timestamp: new Date().toISOString(),
        status: 'success'
    });
    
    updateUI();
    showNotification(`Successfully sent ${amount.toFixed(4)} PLG to ${walletAddress}`, 'success');
    sendAlert(`Transfer: ${amount.toFixed(4)} PLG sent to ${walletAddress}`);
}

// Activate Robot
function activateRobot() {
    const status = document.getElementById('robotStatus');
    const profitIncrease = document.getElementById('profitIncrease');
    
    if (robotInterval) {
        clearInterval(robotInterval);
        robotInterval = null;
        status.textContent = 'Monitoring';
        showNotification('Robot deactivated', 'info');
    } else {
        status.textContent = 'Active';
        let profit = 0;
        
        robotInterval = setInterval(() => {
            profit += Math.random() * 2;
            profitIncrease.textContent = profit.toFixed(2);
            pilgrimCoin.usdValue += 0.001;
            updatePilgrimCoinUI();
        }, 10000);
        
        showNotification('Robot activated - monitoring and increasing value', 'success');
        sendAlert('Robot: Automated trading activated');
    }
}

// Card Management
function processCardPayment() {
    const cardNumber = document.getElementById('cardNumber').value;
    const expiry = document.getElementById('cardExpiry').value;
    const cvv = document.getElementById('cardCvv').value;
    const amount = parseFloat(document.getElementById('cardAmount').value);
    
    if (!cardNumber || !expiry || !cvv || isNaN(amount) || amount <= 0) {
        showNotification('Please fill all card details', 'error');
        return;
    }
    
    // Validate card number (basic validation)
    if (cardNumber.replace(/\s/g, '').length !== 16) {
        showNotification('Invalid card number', 'error');
        return;
    }
    
    // Process payment
    accounts.usd.balance += amount;
    
    addTransaction({
        type: 'card_payment',
        currency: 'usd',
        amount: amount,
        cardLast4: cardNumber.slice(-4),
        account: accounts.usd.accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    });
    
    updateUI();
    showNotification(`Card payment of $${amount.toFixed(2)} accepted successfully`, 'success');
    sendAlert(`Card Payment: $${amount.toFixed(2)} received from card ending in ${cardNumber.slice(-4)}`);
    
    // Clear form
    document.getElementById('cardNumber').value = '';
    document.getElementById('cardExpiry').value = '';
    document.getElementById('cardCvv').value = '';
    document.getElementById('cardAmount').value = '';
}

// Generate Virtual Card
function generateVirtualCard() {
    const card = {
        cardNumber: Array.from({length: 16}, () => Math.floor(Math.random() * 10)).join('').match(/.{1,4}/g).join(' '),
        expiry: `${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}/${String(new Date().getFullYear() + Math.floor(Math.random() * 5)).slice(2)}`,
        cvv: Math.floor(Math.random() * 900) + 100,
        balance: 0,
        currency: 'USD',
        createdAt: new Date().toISOString()
    };
    
    virtualCards.push(card);
    saveVirtualCards();
    updateVirtualCardsUI();
    
    showNotification('Virtual card generated successfully', 'success');
    sendAlert('Virtual Card: New virtual card created');
}

// Update Virtual Cards UI
function updateVirtualCardsUI() {
    const container = document.getElementById('virtualCardsList');
    container.innerHTML = '';
    
    virtualCards.forEach(card => {
        const div = document.createElement('div');
        div.className = 'currency-card usd';
        div.innerHTML = `
            <h3>Virtual Card</h3>
            <p class="card-number">${card.cardNumber}</p>
            <p>Expiry: ${card.expiry}</p>
            <p>CVV: ${card.cvv}</p>
            <p class="balance">$${card.balance.toFixed(2)}</p>
        `;
        container.appendChild(div);
    });
}

// Save/Load Virtual Cards
function saveVirtualCards() {
    localStorage.setItem('virtualCards', JSON.stringify(virtualCards));
}

function loadVirtualCards() {
    const saved = localStorage.getItem('virtualCards');
    if (saved) {
        virtualCards = JSON.parse(saved);
    }
}

// Alert System
function saveAlertSettings() {
    const smsAlerts = document.getElementById('smsAlerts').checked;
    const emailAlerts = document.getElementById('emailAlerts').checked;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const alertEmail = document.getElementById('alertEmail').value;
    
    const settings = {
        smsAlerts,
        emailAlerts,
        phoneNumber,
        alertEmail
    };
    
    localStorage.setItem('alertSettings', JSON.stringify(settings));
    showNotification('Alert settings saved successfully', 'success');
}

function sendAlert(message) {
    const settings = JSON.parse(localStorage.getItem('alertSettings')) || {
        smsAlerts: true,
        emailAlerts: true,
        phoneNumber: '',
        alertEmail: 'adeganglobal@gmail.com'
    };
    
    const alert = {
        id: Date.now(),
        message: message,
        timestamp: new Date().toISOString(),
        sent: {
            sms: settings.smsAlerts && settings.phoneNumber,
            email: settings.emailAlerts && settings.alertEmail
        }
    };
    
    alerts.unshift(alert);
    if (alerts.length > 50) {
        alerts = alerts.slice(0, 50);
    }
    
    saveAlerts();
    updateAlertsUI();
    
    console.log('SMS Alert sent to:', settings.phoneNumber);
    console.log('Email Alert sent to:', settings.alertEmail);
}

function updateAlertsUI() {
    const container = document.getElementById('alertList');
    container.innerHTML = '';
    
    alerts.forEach(alert => {
        const div = document.createElement('div');
        div.className = 'alert-item';
        
        const date = new Date(alert.timestamp);
        const formattedDate = date.toLocaleString();
        
        div.innerHTML = `
            <p><strong>Message:</strong> ${alert.message}</p>
            <p><strong>Date:</strong> ${formattedDate}</p>
            <p><strong>Sent via:</strong> 
                ${alert.sent.sms ? 'SMS ' : ''} 
                ${alert.sent.email ? 'Email' : ''}
            </p>
        `;
        
        container.appendChild(div);
    });
}

function saveAlerts() {
    localStorage.setItem('alerts', JSON.stringify(alerts));
}

function loadAlerts() {
    const saved = localStorage.getItem('alerts');
    if (saved) {
        alerts = JSON.parse(saved);
    }
}

// Cloud Server Management
function updateServerUI() {
    // Simulated server stats
    document.getElementById('storageUsed').textContent = Math.floor(Math.random() * 50);
}

function uploadFiles() {
    const fileInput = document.getElementById('fileUpload');
    if (fileInput.files.length === 0) {
        showNotification('Please select files to upload', 'error');
        return;
    }
    
    showNotification(`Successfully uploaded ${fileInput.files.length} file(s)`, 'success');
    sendAlert(`Cloud Server: ${fileInput.files.length} file(s) uploaded`);
    fileInput.value = '';
}

function createFolder() {
    const folderName = document.getElementById('newFolderName').value;
    if (!folderName) {
        showNotification('Please enter folder name', 'error');
        return;
    }
    
    showNotification(`Folder "${folderName}" created successfully`, 'success');
    sendAlert(`Cloud Server: Folder "${folderName}" created`);
    document.getElementById('newFolderName').value = '';
}

function deploySite() {
    showNotification('Deployment process initiated...', 'info');
    
    setTimeout(() => {
        showNotification('Site deployed successfully!', 'success');
        sendAlert('Cloud Server: Site deployed successfully');
    }, 2000);
}

function connectDomain() {
    const domainName = document.getElementById('domainName').value;
    if (!domainName) {
        showNotification('Please enter domain name', 'error');
        return;
    }
    
    showNotification(`Domain "${domainName}" connected successfully`, 'success');
    sendAlert(`Cloud Server: Domain "${domainName}" connected`);
    document.getElementById('domainName').value = '';
}

function editFile() {
    showNotification('File editor opened', 'info');
}

function deleteFile() {
    if (confirm('Are you sure you want to delete this file?')) {
        showNotification('File deleted successfully', 'success');
        sendAlert('Cloud Server: File deleted');
    }
}

function unzipFile() {
    showNotification('Unzipping folder...', 'info');
    
    setTimeout(() => {
        showNotification('Folder unzipped successfully', 'success');
        sendAlert('Cloud Server: Folder unzipped');
    }, 1500);
}

// Notification System
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '20px';
    notification.style.borderRadius = '10px';
    notification.style.color = 'white';
    notification.style.zIndex = '9999';
    notification.style.animation = 'slideIn 0.3s ease';
    
    const colors = {
        success: 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)',
        error: 'linear-gradient(135deg, #eb3349 0%, #f45c43 100%)',
        info: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        warning: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
    };
    
    notification.style.background = colors[type] || colors.info;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);