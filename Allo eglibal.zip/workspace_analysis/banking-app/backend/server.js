const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('frontend'));

// File upload configuration
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = 'uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Owner Information
const owner = {
    name: 'Olawale Abdul-Ganiyu Adeshina',
    email: 'adeganglobal@gmail.com',
    age: 40,
    sex: 'Male',
    position: 'Founder & CEO'
};

// Database (in-memory for demo)
let accounts = {};
let transactions = [];
let pilgrimCoin = {
    balance: 0,
    wallet: '',
    mining: false,
    mined: 0,
    rate: 0.01,
    usdValue: 0.5
};

// Initialize accounts
function initializeAccounts() {
    const currencies = ['usd', 'eur', 'ngn', 'gbp', 'cny'];
    currencies.forEach(currency => {
        accounts[currency] = {
            accountNumber: generateAccountNumber(),
            wallet: generateWalletAddress(),
            balance: 0,
            serialNumber: generateSerialNumber()
        };
    });
    pilgrimCoin.wallet = generateWalletAddress();
}

// Helper functions
function generateAccountNumber() {
    const length = Math.floor(Math.random() * 10) + 1;
    let accountNumber = '';
    for (let i = 0; i < length; i++) {
        accountNumber += Math.floor(Math.random() * 10);
    }
    return accountNumber.padStart(10, '0').substring(0, 10);
}

function generateSerialNumber() {
    return 'GBN-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9).toUpperCase();
}

function generateWalletAddress() {
    return '0x' + Array.from({length: 40}, () => Math.floor(Math.random() * 16).toString(16)).join('');
}

// Routes

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Global Bank Nigeria API is running' });
});

// Owner information
app.get('/api/owner', (req, res) => {
    res.json(owner);
});

// Get all accounts
app.get('/api/accounts', (req, res) => {
    res.json(accounts);
});

// Get specific account
app.get('/api/accounts/:currency', (req, res) => {
    const currency = req.params.currency.toLowerCase();
    if (accounts[currency]) {
        res.json(accounts[currency]);
    } else {
        res.status(404).json({ error: 'Account not found' });
    }
});

// Credit account
app.post('/api/accounts/:currency/credit', (req, res) => {
    const currency = req.params.currency.toLowerCase();
    const { amount } = req.body;
    
    if (!accounts[currency]) {
        return res.status(404).json({ error: 'Account not found' });
    }
    
    if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
    }
    
    accounts[currency].balance += amount;
    
    const transaction = {
        id: Date.now(),
        type: 'credit',
        currency: currency,
        amount: amount,
        account: accounts[currency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    transactions.unshift(transaction);
    
    res.json({ success: true, balance: accounts[currency].balance, transaction });
});

// Debit account
app.post('/api/accounts/:currency/debit', (req, res) => {
    const currency = req.params.currency.toLowerCase();
    const { amount } = req.body;
    
    if (!accounts[currency]) {
        return res.status(404).json({ error: 'Account not found' });
    }
    
    if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
    }
    
    if (accounts[currency].balance < amount) {
        return res.status(400).json({ error: 'Insufficient balance' });
    }
    
    accounts[currency].balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: 'debit',
        currency: currency,
        amount: amount,
        account: accounts[currency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    transactions.unshift(transaction);
    
    res.json({ success: true, balance: accounts[currency].balance, transaction });
});

// Process transaction
app.post('/api/transactions', (req, res) => {
    const { currency, type, recipient, amount, bank } = req.body;
    
    if (!accounts[currency]) {
        return res.status(404).json({ error: 'Account not found' });
    }
    
    if (!recipient || isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: 'Invalid transaction details' });
    }
    
    if (accounts[currency].balance < amount) {
        return res.status(400).json({ error: 'Insufficient balance' });
    }
    
    accounts[currency].balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: type,
        currency: currency,
        amount: amount,
        recipient: recipient,
        bank: bank || 'Unknown',
        account: accounts[currency].accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    transactions.unshift(transaction);
    
    res.json({ success: true, transaction });
});

// Get transactions
app.get('/api/transactions', (req, res) => {
    res.json(transactions.slice(0, 50)); // Return last 50 transactions
});

// Pilgrim Coin endpoints
app.get('/api/pilgrim', (req, res) => {
    res.json(pilgrimCoin);
});

app.post('/api/pilgrim/mine', (req, res) => {
    if (pilgrimCoin.mining) {
        return res.status(400).json({ error: 'Mining is already active' });
    }
    
    pilgrimCoin.mining = true;
    
    // Simulate mining
    const miningInterval = setInterval(() => {
        pilgrimCoin.balance += pilgrimCoin.rate;
        pilgrimCoin.mined += pilgrimCoin.rate;
    }, 60000);
    
    res.json({ success: true, message: 'Mining started' });
});

app.post('/api/pilgrim/transfer', (req, res) => {
    const { amount, targetWallet } = req.body;
    
    if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
    }
    
    if (pilgrimCoin.balance < amount) {
        return res.status(400).json({ error: 'Insufficient balance' });
    }
    
    pilgrimCoin.balance -= amount;
    
    const transaction = {
        id: Date.now(),
        type: 'pilgrim_transfer',
        currency: 'plg',
        amount: amount,
        recipient: targetWallet,
        account: pilgrimCoin.wallet,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    transactions.unshift(transaction);
    
    res.json({ success: true, balance: pilgrimCoin.balance, transaction });
});

app.post('/api/pilgrim/convert', (req, res) => {
    const { amount } = req.body;
    
    if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
    }
    
    if (pilgrimCoin.balance < amount) {
        return res.status(400).json({ error: 'Insufficient balance' });
    }
    
    pilgrimCoin.balance -= amount;
    const usdValue = amount * pilgrimCoin.usdValue;
    accounts.usd.balance += usdValue;
    
    const transaction = {
        id: Date.now(),
        type: 'pilgrim_to_balance',
        currency: 'usd',
        amount: usdValue,
        account: accounts.usd.accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    transactions.unshift(transaction);
    
    res.json({ success: true, usdBalance: accounts.usd.balance, transaction });
});

// Card payment processing
app.post('/api/cards/payment', (req, res) => {
    const { cardNumber, expiry, cvv, amount } = req.body;
    
    // Basic validation
    if (!cardNumber || !expiry || !cvv || isNaN(amount) || amount <= 0) {
        return res.status(400).json({ error: 'Invalid card details' });
    }
    
    if (cardNumber.replace(/\s/g, '').length !== 16) {
        return res.status(400).json({ error: 'Invalid card number' });
    }
    
    // Process payment
    accounts.usd.balance += amount;
    
    const transaction = {
        id: Date.now(),
        type: 'card_payment',
        currency: 'usd',
        amount: amount,
        cardLast4: cardNumber.slice(-4),
        account: accounts.usd.accountNumber,
        timestamp: new Date().toISOString(),
        status: 'success'
    };
    
    transactions.unshift(transaction);
    
    res.json({ success: true, balance: accounts.usd.balance, transaction });
});

// Virtual card generation
app.post('/api/cards/virtual', (req, res) => {
    const card = {
        cardNumber: Array.from({length: 16}, () => Math.floor(Math.random() * 10)).join('').match(/.{1,4}/g).join(' '),
        expiry: `${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}/${String(new Date().getFullYear() + Math.floor(Math.random() * 5)).slice(2)}`,
        cvv: Math.floor(Math.random() * 900) + 100,
        balance: 0,
        currency: 'USD',
        createdAt: new Date().toISOString()
    };
    
    res.json({ success: true, card });
});

// File upload
app.post('/api/upload', upload.array('files', 10), (req, res) => {
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files uploaded' });
    }
    
    const fileNames = req.files.map(file => file.filename);
    res.json({ success: true, files: fileNames, count: fileNames.length });
});

// Cloud server management
app.post('/api/server/folder', (req, res) => {
    const { folderName } = req.body;
    
    if (!folderName) {
        return res.status(400).json({ error: 'Folder name required' });
    }
    
    const folderPath = path.join(__dirname, 'uploads', folderName);
    
    if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath, { recursive: true });
        res.json({ success: true, message: 'Folder created', path: folderPath });
    } else {
        res.status(400).json({ error: 'Folder already exists' });
    }
});

app.post('/api/server/unzip', (req, res) => {
    const { filePath } = req.body;
    
    if (!filePath) {
        return res.status(400).json({ error: 'File path required' });
    }
    
    const fullPath = path.join(__dirname, 'uploads', filePath);
    
    if (!fs.existsSync(fullPath)) {
        return res.status(404).json({ error: 'File not found' });
    }
    
    // Execute unzip command
    exec(`unzip -o "${fullPath}" -d "${path.dirname(fullPath)}"`, (error, stdout, stderr) => {
        if (error) {
            return res.status(500).json({ error: 'Unzip failed', details: stderr });
        }
        res.json({ success: true, message: 'File unzipped successfully' });
    });
});

app.post('/api/server/deploy', (req, res) => {
    const { domain } = req.body;
    
    if (!domain) {
        return res.status(400).json({ error: 'Domain name required' });
    }
    
    // Simulate deployment
    res.json({ 
        success: true, 
        message: 'Deployment initiated', 
        domain: domain,
        status: 'processing'
    });
});

// File browser
app.get('/api/server/files', (req, res) => {
    const uploadsDir = path.join(__dirname, 'uploads');
    
    if (!fs.existsSync(uploadsDir)) {
        return res.json({ files: [] });
    }
    
    const files = fs.readdirSync(uploadsDir).map(file => {
        const filePath = path.join(uploadsDir, file);
        const stats = fs.statSync(filePath);
        
        return {
            name: file,
            size: stats.size,
            isDirectory: stats.isDirectory(),
            modified: stats.mtime
        };
    });
    
    res.json({ files });
});

// Delete file
app.delete('/api/server/files/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);
    
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found' });
    }
    
    fs.unlinkSync(filePath);
    res.json({ success: true, message: 'File deleted' });
});

// Admin login
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    // Hardcoded admin credentials (in production, use proper authentication)
    if (username === 'admin' && password === 'admin123') {
        res.json({ 
            success: true, 
            token: 'fake-jwt-token',
            user: {
                name: owner.name,
                email: owner.email,
                role: 'admin'
            }
        });
    } else {
        res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
});

// Initialize and start server
initializeAccounts();

app.listen(PORT, () => {
    console.log(`
╔═════════════════════════════════════════════════════════╗
║           Global Bank Nigeria - Server                ║
║                                                        ║
║  Status: Online                                        ║
║  Port: ${PORT}                                           ║
║  Owner: ${owner.name}                                ║
║                                                        ║
║  API Endpoints:                                       ║
║  - GET  /api/health                                   ║
║  - GET  /api/owner                                    ║
║  - GET  /api/accounts                                 ║
║  - POST /api/accounts/:currency/credit                ║
║  - POST /api/accounts/:currency/debit                 ║
║  - POST /api/transactions                             ║
║  - GET  /api/transactions                             ║
║  - GET  /api/pilgrim                                  ║
║  - POST /api/pilgrim/mine                             ║
║  - POST /api/pilgrim/transfer                         ║
║  - POST /api/pilgrim/convert                          ║
║  - POST /api/cards/payment                            ║
║  - POST /api/cards/virtual                            ║
║  - POST /api/upload                                   ║
║  - GET  /api/server/files                             ║
║  - POST /api/server/folder                            ║
║  - POST /api/server/unzip                             ║
║  - POST /api/server/deploy                            ║
║  - POST /api/login                                    ║
╚═════════════════════════════════════════════════════════╝
    `);
});