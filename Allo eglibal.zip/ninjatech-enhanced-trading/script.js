// NinjaTech Enhanced Trading - Advanced Trading Platform
// Owner: Olawale Abdul-Ganiyu Adeshina
// Features: MetaTrader 4/5 Integration, Micro Accounts, Auto Trading, Best Trade Recommendations

// ==================== GLOBAL VARIABLES ====================
let currentUser = {
    name: 'Olawale Abdul-Ganiyu Adeshina',
    email: 'adeganglobal@gmail.com',
    age: 40,
    country: 'Nigeria',
    state: 'Ogun',
    city: 'Ikeja, Lagos',
    phone: '+234 903 027 7275'
};

let wallet = {
    balance: 10000.00,
    deposits: 15000.00,
    withdrawals: 5000.00,
    profit: 450.00,
    loss: 150.00
};

let tradingAccounts = [
    {
        id: 1,
        accountNumber: '123456789',
        platform: 'mt5',
        type: 'Standard',
        leverage: '1:500',
        balance: 10000.00,
        equity: 10450.00,
        margin: 250.00,
        freeMargin: 10200.00,
        marginLevel: 4180,
        status: 'active'
    },
    {
        id: 2,
        accountNumber: '987654321',
        platform: 'mt5',
        type: 'Micro',
        leverage: '1:1000',
        balance: 500.00,
        equity: 525.00,
        margin: 25.00,
        freeMargin: 500.00,
        marginLevel: 2100,
        status: 'active'
    }
];

let currentAccount = tradingAccounts[0];
let openPositions = [];
let tradeHistory = [];
let signals = [];
let autoTradeBot = {
    active: true,
    riskLevel: 'medium',
    maxDailyLoss: 500,
    maxDailyTrades: 10,
    tradesToday: 0,
    lossToday: 0,
    totalTrades: 156,
    winRate: 82,
    totalProfit: 2450.00,
    runningSince: '2024-12-10'
};

let marketData = {
    EURUSD: { bid: 1.0856, ask: 1.0858, change: 0.15 },
    GBPUSD: { bid: 1.2643, ask: 1.2645, change: -0.22 },
    USDJPY: { bid: 149.85, ask: 149.87, change: 0.18 },
    XAUUSD: { bid: 2043.50, ask: 2044.00, change: 0.45 },
    BTCUSD: { bid: 43750.00, ask: 43800.00, change: 2.30 },
    ETHUSD: { bid: 2280.00, ask: 2285.00, change: 1.85 }
};

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    initializeMarketData();
    initializeSignals();
    initializePositions();
    updateDashboard();
    
    // Start price updates
    setInterval(updatePrices, 1000);
    setInterval(updateDashboard, 5000);
});

// ==================== AUTHENTICATION ====================
function handleLogin() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simple validation
    if (!email || !password) {
        showNotification('Please enter email and password', 'error');
        return;
    }
    
    // Check for admin login
    if (email === 'admin@ninjatech.com' && password === 'NinjaTech@2024') {
        showNotification('Welcome, NinjaTech Admin!', 'success');
        showAdminPanel();
        return;
    }
    
    // For demo, accept any login
    showDashboard();
    showNotification('Welcome back, ' + currentUser.name + '!', 'success');
}

function showAdminPanel() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'block';
    updateAdminDashboard();
}

function updateAdminDashboard() {
    document.getElementById('adminTotalUsers').textContent = '1';
    document.getElementById('adminTotalAccounts').textContent = tradingAccounts.length;
    document.getElementById('adminOpenTrades').textContent = openPositions.length;
    document.getElementById('adminTotalBalance').textContent = formatCurrency(wallet.balance);
}

function logout() {
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('dashboardSection').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'none';
    
    saveToStorage();
}

// ==================== DASHBOARD ====================
function showDashboard() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
    
    document.getElementById('userName').textContent = currentUser.name;
    updateDashboard();
}

function updateDashboard() {
    // Update total balance
    document.getElementById('totalBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('openPositions').textContent = openPositions.length;
    
    // Update wallet displays
    document.getElementById('walletMainBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('totalDeposits').textContent = formatCurrency(wallet.deposits);
    document.getElementById('totalWithdrawals').textContent = formatCurrency(wallet.withdrawals);
    document.getElementById('totalProfit').textContent = formatCurrency(wallet.profit);
    document.getElementById('totalLoss').textContent = formatCurrency(wallet.loss);
    
    // Update trading displays
    document.getElementById('tradingBalance').textContent = formatCurrency(currentAccount.balance);
    document.getElementById('tradingEquity').textContent = formatCurrency(currentAccount.equity);
    document.getElementById('tradingMargin').textContent = formatCurrency(currentAccount.margin);
    document.getElementById('freeMargin').textContent = formatCurrency(currentAccount.freeMargin);
    document.getElementById('marginLevel').textContent = formatNumber(currentAccount.marginLevel);
    
    // Update market overview
    updateMarketOverview();
}

function updateMarketOverview() {
    const marketItems = document.querySelectorAll('.market-item');
    const symbols = Object.keys(marketData);
    
    marketItems.forEach((item, index) => {
        if (symbols[index]) {
            const symbol = symbols[index];
            const data = marketData[symbol];
            
            item.querySelector('.symbol').textContent = symbol.replace('USD', '/USD');
            item.querySelector('.price').textContent = formatPrice(data.bid);
            
            const changeEl = item.querySelector('.change');
            changeEl.textContent = (data.change >= 0 ? '+' : '') + data.change.toFixed(2) + '%';
            changeEl.className = 'change ' + (data.change >= 0 ? 'positive' : 'negative');
        }
    });
}

// ==================== NAVIGATION ====================
function showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    const targetSection = document.getElementById(sectionId + 'Section');
    if (targetSection) {
        targetSection.style.display = 'block';
    } else if (sectionId === 'dashboard') {
        document.getElementById('dashboardSectionContent').style.display = 'block';
    }
    
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
}

// ==================== TRADING ====================
function changePlatform() {
    const platform = document.getElementById('platformSelect').value;
    showNotification(`Switched to MetaTrader ${platform.charAt(2)}`, 'success');
}

function setOrderType(type) {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
}

function placeOrder(direction) {
    const symbol = document.getElementById('orderSymbol').value;
    const lotSize = parseFloat(document.getElementById('lotSize').value) || 0;
    const stopLoss = parseFloat(document.getElementById('stopLoss').value) || 0;
    const takeProfit = parseFloat(document.getElementById('takeProfit').value) || 0;
    
    if (lotSize <= 0) {
        showNotification('Please enter a valid lot size', 'error');
        return;
    }
    
    const currentPrice = marketData[symbol.toUpperCase().replace('/', '')]?.bid || 1.0856;
    
    // Create position
    const position = {
        id: Date.now(),
        symbol: symbol.replace('USD', '/USD'),
        type: direction.toUpperCase(),
        lots: lotSize,
        openPrice: currentPrice,
        currentPrice: currentPrice,
        stopLoss: stopLoss || null,
        takeProfit: takeProfit || null,
        profit: 0,
        openTime: new Date().toISOString()
    };
    
    openPositions.push(position);
    
    // Update account
    currentAccount.margin += (lotSize * 100);
    currentAccount.freeMargin = currentAccount.equity - currentAccount.margin;
    currentAccount.marginLevel = (currentAccount.equity / currentAccount.margin) * 100;
    
    saveToStorage();
    updatePositionsTable();
    updateDashboard();
    
    showNotification(`${direction.toUpperCase()} order placed for ${position.symbol}`, 'success');
}

function closePosition(positionId) {
    const index = openPositions.findIndex(p => p.id === positionId);
    if (index !== -1) {
        const position = openPositions[index];
        
        // Calculate final profit
        const priceDiff = position.type === 'BUY' 
            ? (position.currentPrice - position.openPrice)
            : (position.openPrice - position.currentPrice);
        position.profit = priceDiff * position.lots * 100000;
        
        // Update wallet
        if (position.profit > 0) {
            wallet.profit += position.profit;
            currentAccount.balance += position.profit;
        } else {
            wallet.loss += Math.abs(position.profit);
            currentAccount.balance += position.profit;
        }
        
        currentAccount.equity = currentAccount.balance + calculateFloatingProfit();
        currentAccount.margin -= (position.lots * 100);
        currentAccount.freeMargin = currentAccount.equity - currentAccount.margin;
        currentAccount.marginLevel = (currentAccount.equity / currentAccount.margin) * 100;
        
        // Add to history
        tradeHistory.unshift({
            ...position,
            closePrice: position.currentPrice,
            closeTime: new Date().toISOString()
        });
        
        // Remove from open positions
        openPositions.splice(index, 1);
        
        saveToStorage();
        updatePositionsTable();
        updateDashboard();
        updateTradeHistory();
        
        showNotification(`Position closed: ${formatCurrency(position.profit)}`, position.profit >= 0 ? 'success' : 'warning');
    }
}

function updatePositionsTable() {
    const tbody = document.getElementById('positionsTableBody');
    
    if (openPositions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No open positions</td></tr>';
        return;
    }
    
    tbody.innerHTML = openPositions.map(position => {
        const profit = calculatePositionProfit(position);
        return `
            <tr>
                <td>${position.symbol}</td>
                <td class="${position.type.toLowerCase()}">${position.type}</td>
                <td>${position.lots.toFixed(2)}</td>
                <td>${formatPrice(position.openPrice)}</td>
                <td>${formatPrice(position.currentPrice)}</td>
                <td class="${profit >= 0 ? 'positive' : 'negative'}">${formatCurrency(profit)}</td>
                <td><button class="btn-close" onclick="closePosition(${position.id})">Close</button></td>
            </tr>
        `;
    }).join('');
}

function calculatePositionProfit(position) {
    const priceDiff = position.type === 'BUY'
        ? (position.currentPrice - position.openPrice)
        : (position.openPrice - position.currentPrice);
    return priceDiff * position.lots * 100000;
}

function calculateFloatingProfit() {
    return openPositions.reduce((sum, position) => sum + calculatePositionProfit(position), 0);
}

// ==================== MARKET DATA ====================
function initializeMarketData() {
    // Add sample open positions
    openPositions = [
        {
            id: 1,
            symbol: 'EUR/USD',
            type: 'BUY',
            lots: 0.10,
            openPrice: 1.0840,
            currentPrice: 1.0856,
            stopLoss: null,
            takeProfit: null,
            profit: 160,
            openTime: '2024-12-15T10:30:00'
        },
        {
            id: 2,
            symbol: 'GBP/USD',
            type: 'SELL',
            lots: 0.05,
            openPrice: 1.2670,
            currentPrice: 1.2643,
            stopLoss: null,
            takeProfit: null,
            profit: 135,
            openTime: '2024-12-15T11:15:00'
        },
        {
            id: 3,
            symbol: 'XAU/USD',
            type: 'BUY',
            lots: 0.02,
            openPrice: 2038.00,
            currentPrice: 2043.50,
            stopLoss: null,
            takeProfit: null,
            profit: 110,
            openTime: '2024-12-15T14:20:00'
        }
    ];
    
    // Add sample trade history
    tradeHistory = [
        {
            id: 101,
            symbol: 'EUR/USD',
            type: 'BUY',
            lots: 0.10,
            openPrice: 1.0840,
            closePrice: 1.0865,
            profit: 250,
            openTime: '2024-12-15T09:00:00',
            closeTime: '2024-12-15T10:00:00'
        },
        {
            id: 102,
            symbol: 'GBP/USD',
            type: 'SELL',
            lots: 0.05,
            openPrice: 1.2670,
            closePrice: 1.2643,
            profit: 135,
            openTime: '2024-12-15T10:30:00',
            closeTime: '2024-12-15T11:30:00'
        },
        {
            id: 103,
            symbol: 'USD/JPY',
            type: 'BUY',
            lots: 0.08,
            openPrice: 149.50,
            closePrice: 149.20,
            profit: -240,
            openTime: '2024-12-14T15:00:00',
            closeTime: '2024-12-14T16:30:00'
        }
    ];
}

function updatePrices() {
    // Simulate price movements
    Object.keys(marketData).forEach(symbol => {
        const change = (Math.random() - 0.5) * 0.001;
        marketData[symbol].bid = Math.max(0, marketData[symbol].bid * (1 + change));
        marketData[symbol].ask = marketData[symbol].bid + 0.0002;
        marketData[symbol].change = (Math.random() - 0.5) * 0.5;
    });
    
    // Update current price display
    const currentSymbol = document.getElementById('symbol')?.value;
    if (currentSymbol && marketData[currentSymbol]) {
        document.getElementById('currentPrice').textContent = formatPrice(marketData[currentSymbol].bid);
    }
    
    // Update open positions
    openPositions.forEach(position => {
        const symbolKey = position.symbol.replace('/', '');
        if (marketData[symbolKey]) {
            position.currentPrice = marketData[symbolKey].bid;
            position.profit = calculatePositionProfit(position);
        }
    });
    
    // Update floating profit
    const floatingProfit = calculateFloatingProfit();
    currentAccount.equity = currentAccount.balance + floatingProfit;
    currentAccount.freeMargin = currentAccount.equity - currentAccount.margin;
    if (currentAccount.margin > 0) {
        currentAccount.marginLevel = (currentAccount.equity / currentAccount.margin) * 100;
    }
    
    updatePositionsTable();
    updateDashboard();
}

// ==================== SIGNALS ====================
function initializeSignals() {
    signals = [
        {
            id: 1,
            pair: 'EUR/USD',
            type: 'BUY',
            entry: 1.0850,
            takeProfit: 1.0950,
            stopLoss: 1.0800,
            riskReward: '1:2',
            timeframe: 'H4',
            confidence: 90
        },
        {
            id: 2,
            pair: 'XAU/USD',
            type: 'BUY',
            entry: 2040.00,
            takeProfit: 2080.00,
            stopLoss: 2020.00,
            riskReward: '1:2',
            timeframe: 'D1',
            confidence: 88
        },
        {
            id: 3,
            pair: 'BTC/USD',
            type: 'BUY',
            entry: 43500.00,
            takeProfit: 48000.00,
            stopLoss: 41000.00,
            riskReward: '1:1.5',
            timeframe: 'H4',
            confidence: 85
        }
    ];
}

// ==================== AUTO TRADE ====================
function toggleBot() {
    autoTradeBot.active = !autoTradeBot.active;
    const btn = event.target;
    
    if (autoTradeBot.active) {
        btn.textContent = 'Stop Bot';
        btn.style.background = '#f44336';
        showNotification('Auto trade bot activated', 'success');
    } else {
        btn.textContent = 'Start Bot';
        btn.style.background = '#4caf50';
        showNotification('Auto trade bot deactivated', 'warning');
    }
    
    saveToStorage();
}

// ==================== WALLET ====================
function showDepositModal() {
    document.getElementById('withdrawAvailableBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('depositModal').style.display = 'flex';
}

function showWithdrawModal() {
    document.getElementById('withdrawAvailableBalance').textContent = formatCurrency(wallet.balance);
    document.getElementById('withdrawModal').style.display = 'flex';
}

function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
}

function processDeposit() {
    const amount = parseFloat(document.getElementById('depositAmount').value) || 0;
    const method = document.getElementById('depositMethod').value;
    
    if (amount < 100) {
        showNotification('Minimum deposit is $100', 'error');
        return;
    }
    
    wallet.balance += amount;
    wallet.deposits += amount;
    currentAccount.balance += amount;
    currentAccount.equity += amount;
    
    saveToStorage();
    updateDashboard();
    closeModals();
    
    showNotification(`Deposit of $${formatCurrency(amount)} successful via ${method.toUpperCase()}`, 'success');
    document.getElementById('depositAmount').value = '';
}

function processWithdrawal() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value) || 0;
    const method = document.getElementById('withdrawMethod').value;
    
    if (amount < 50) {
        showNotification('Minimum withdrawal is $50', 'error');
        return;
    }
    
    if (amount > wallet.balance) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    wallet.balance -= amount;
    wallet.withdrawals += amount;
    currentAccount.balance -= amount;
    currentAccount.equity -= amount;
    
    saveToStorage();
    updateDashboard();
    closeModals();
    
    showNotification(`Withdrawal of $${formatCurrency(amount)} submitted via ${method.toUpperCase()}`, 'success');
    document.getElementById('withdrawAmount').value = '';
}

// ==================== TRADE HISTORY ====================
function updateTradeHistory() {
    // Update trade history table if it exists
    const historyTable = document.querySelector('.history-table tbody');
    if (historyTable && tradeHistory.length > 0) {
        historyTable.innerHTML = tradeHistory.slice(0, 10).map(trade => `
            <tr>
                <td>${new Date(trade.closeTime).toLocaleDateString()}</td>
                <td>${trade.symbol}</td>
                <td class="${trade.type.toLowerCase()}">${trade.type}</td>
                <td>${trade.lots.toFixed(2)}</td>
                <td>${formatPrice(trade.openPrice)}</td>
                <td>${formatPrice(trade.closePrice)}</td>
                <td class="${trade.profit >= 0 ? 'positive' : 'negative'}">${formatCurrency(trade.profit)}</td>
            </tr>
        `).join('');
    }
}

// ==================== UTILITY FUNCTIONS ====================
function formatCurrency(amount) {
    return parseFloat(amount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatPrice(price) {
    if (price >= 1000) {
        return price.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
    return price.toFixed(4);
}

function formatNumber(number) {
    return Math.round(number).toLocaleString();
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// ==================== STORAGE ====================
function saveToStorage() {
    localStorage.setItem('tradingWallet', JSON.stringify(wallet));
    localStorage.setItem('tradingAccounts', JSON.stringify(tradingAccounts));
    localStorage.setItem('tradingPositions', JSON.stringify(openPositions));
    localStorage.setItem('tradingHistory', JSON.stringify(tradeHistory));
    localStorage.setItem('autoTradeBot', JSON.stringify(autoTradeBot));
}

function loadFromStorage() {
    const storedWallet = localStorage.getItem('tradingWallet');
    if (storedWallet) {
        wallet = JSON.parse(storedWallet);
    }
    
    const storedAccounts = localStorage.getItem('tradingAccounts');
    if (storedAccounts) {
        tradingAccounts = JSON.parse(storedAccounts);
        currentAccount = tradingAccounts[0] || tradingAccounts[0];
    }
    
    const storedPositions = localStorage.getItem('tradingPositions');
    if (storedPositions) {
        openPositions = JSON.parse(storedPositions);
    }
    
    const storedHistory = localStorage.getItem('tradingHistory');
    if (storedHistory) {
        tradeHistory = JSON.parse(storedHistory);
    }
    
    const storedBot = localStorage.getItem('autoTradeBot');
    if (storedBot) {
        autoTradeBot = JSON.parse(storedBot);
    }
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModals();
    }
}