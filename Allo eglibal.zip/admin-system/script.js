// Admin Portal - Global Trading Ventures
// Owner: Olawale Abdul-Ganiyu Adeshina

// ==================== ADMIN CREDENTIALS ====================
const adminCredentials = {
    email: 'adeganglobal@gmail.com',
    password: 'admin123',
    name: 'Olawale Abdul-Ganiyu Adeshina',
    phone: '+234 903 027 7275',
    location: 'Ikeja, Lagos, Ogun State, Nigeria'
};

// ==================== GLOBAL VARIABLES ====================
let isLoggedIn = false;
let currentPlatform = 'all';

let customers = [];
let transactions = [];
let pendingRegistrations = [];
let pendingDeposits = [];
let pendingWithdrawals = [];
let pendingPayments = [];
let messages = [];

let adminWallet = {
    NGN: 0,
    USD: 0,
    BTC: 0,
    USDT: 0,
    PLG: 0 // Pilgrim Coin
};

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    
    // Check if already logged in
    const loggedAdmin = localStorage.getItem('loggedAdmin');
    if (loggedAdmin) {
        isLoggedIn = true;
        showDashboard();
    }
    
    // Initialize sample data if empty
    if (customers.length === 0) {
        initializeSampleData();
    }
    
    updateDashboard();
});

// ==================== AUTHENTICATION ====================
function handleAdminLogin() {
    const email = document.getElementById('adminEmail').value;
    const password = document.getElementById('adminPassword').value;
    const platform = document.getElementById('platformSelect').value;
    
    // Validate credentials
    if (email !== adminCredentials.email || password !== adminCredentials.password) {
        showNotification('Invalid admin credentials', 'error');
        return;
    }
    
    isLoggedIn = true;
    currentPlatform = platform;
    localStorage.setItem('loggedAdmin', 'true');
    localStorage.setItem('currentPlatform', platform);
    
    showNotification('Welcome, ' + adminCredentials.name + '!', 'success');
    showDashboard();
}

function adminLogout() {
    isLoggedIn = false;
    localStorage.removeItem('loggedAdmin');
    localStorage.removeItem('currentPlatform');
    
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('dashboardSection').style.display = 'none';
    
    showNotification('Logged out successfully', 'success');
}

// ==================== DASHBOARD ====================
function showDashboard() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
    updateDashboard();
}

function updateDashboard() {
    // Update stats
    document.getElementById('totalCustomers').textContent = customers.length;
    document.getElementById('pendingApprovals').textContent = 
        pendingRegistrations.length + 
        pendingDeposits.length + 
        pendingWithdrawals.length + 
        pendingPayments.length;
    document.getElementById('totalTransactions').textContent = transactions.length;
    
    // Calculate total balance
    const totalBalanceNGN = customers.reduce((sum, c) => sum + (c.balanceNGN || 0), 0);
    document.getElementById('totalBalance').textContent = formatCurrency(totalBalanceNGN);
    
    // Update platform stats
    updatePlatformStats();
    
    // Update admin wallet
    document.getElementById('adminNGNBalance').textContent = formatCurrency(adminWallet.NGN);
    document.getElementById('adminUSDBalance').textContent = formatCurrency(adminWallet.USD);
    document.getElementById('adminBTCBalance').textContent = adminWallet.BTC.toFixed(4);
    document.getElementById('adminUSDTBalance').textContent = formatCurrency(adminWallet.USDT);
    
    // Update customer table
    renderCustomersTable();
    
    // Update transaction table
    renderTransactionsTable();
    
    // Update approvals
    renderPendingApprovals();
    
    // Update credit/debit dropdowns
    updateCustomerDropdowns();
    
    // Update messages
    renderMessages();
}

function updatePlatformStats() {
    const platforms = ['commodity', 'count', 'betting', 'trading', 'pilgrim'];
    
    platforms.forEach(platform => {
        const platformCustomers = customers.filter(c => c.platform === platform);
        const platformBalance = platformCustomers.reduce((sum, c) => {
            return sum + (platform === 'trading' || platform === 'pilgrim' 
                ? (c.balanceUSD || 0) 
                : (c.balanceNGN || 0));
        }, 0);
        
        const elementId = platform + (platform === 'trading' || platform === 'pilgrim' ? 'Balance' : 'Balance');
        const element = document.getElementById(elementId);
        if (element) {
            const currency = platform === 'trading' || platform === 'pilgrim' ? '$' : '₦';
            element.textContent = formatCurrency(platformBalance);
        }
        
        const usersElementId = platform + 'Users';
        const usersElement = document.getElementById(usersElementId);
        if (usersElement) {
            usersElement.textContent = platformCustomers.length;
        }
    });
}

// ==================== NAVIGATION ====================
function showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.style.display = 'none');
    
    const targetSection = document.getElementById(sectionId + 'Section');
    if (targetSection) {
        targetSection.style.display = 'block';
    } else if (sectionId === 'overview') {
        document.getElementById('overviewSection').style.display = 'block';
    }
    
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    event.target.classList.add('active');
}

// ==================== CUSTOMER MANAGEMENT ====================
function renderCustomersTable() {
    const tbody = document.getElementById('customersTableBody');
    const searchTerm = document.getElementById('customerSearch')?.value.toLowerCase() || '';
    const platformFilter = document.getElementById('platformFilter')?.value || 'all';
    const statusFilter = document.getElementById('statusFilter')?.value || 'all';
    
    let filteredCustomers = [...customers];
    
    // Apply filters
    if (searchTerm) {
        filteredCustomers = filteredCustomers.filter(c => 
            c.name.toLowerCase().includes(searchTerm) ||
            c.email.toLowerCase().includes(searchTerm) ||
            c.phone.includes(searchTerm)
        );
    }
    
    if (platformFilter !== 'all') {
        filteredCustomers = filteredCustomers.filter(c => c.platform === platformFilter);
    }
    
    if (statusFilter !== 'all') {
        filteredCustomers = filteredCustomers.filter(c => c.status === statusFilter);
    }
    
    if (filteredCustomers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No customers found</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredCustomers.map(customer => `
        <tr>
            <td>${customer.id}</td>
            <td>${customer.name}</td>
            <td>${customer.email}</td>
            <td>${customer.phone}</td>
            <td>${getPlatformName(customer.platform)}</td>
            <td>${formatCurrency(customer.balanceNGN || 0)} / $${formatCurrency(customer.balanceUSD || 0)}</td>
            <td><span class="status-badge ${customer.status}">${customer.status}</span></td>
            <td class="action-buttons">
                <button class="btn-action edit" onclick="editCustomer(${customer.id})">✏️ Edit</button>
                <button class="btn-action ${customer.status === 'blocked' ? 'unblock' : 'block'}" onclick="toggleCustomerStatus(${customer.id})">
                    ${customer.status === 'blocked' ? '🔓 Unblock' : '🔒 Block'}
                </button>
                <button class="btn-action delete" onclick="deleteCustomer(${customer.id})">🗑️ Delete</button>
            </td>
        </tr>
    `).join('');
}

function getPlatformName(platform) {
    const names = {
        'commodity': 'Commodity Market',
        'count': 'Count Trading',
        'betting': 'NinjaBet',
        'trading': 'Enhanced Trading',
        'pilgrim': 'Pilgrim Wallet'
    };
    return names[platform] || platform;
}

function searchCustomers() {
    renderCustomersTable();
}

function filterCustomersByPlatform() {
    renderCustomersTable();
}

function filterCustomersByStatus() {
    renderCustomersTable();
}

// ==================== REGISTER CUSTOMER ====================
function registerCustomer() {
    const name = document.getElementById('regCustomerName').value;
    const email = document.getElementById('regCustomerEmail').value;
    const phone = document.getElementById('regCustomerPhone').value;
    const password = document.getElementById('regCustomerPassword').value;
    const address = document.getElementById('regCustomerAddress').value;
    const platform = document.getElementById('regPlatform').value;
    const initialBalance = parseFloat(document.getElementById('regInitialBalance').value) || 0;
    const passport = document.getElementById('regPassport').files[0];
    const idDocument = document.getElementById('regIDDocument').files[0];
    
    // Validation
    if (!name || !email || !phone || !password || !platform) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    // Check if email already exists
    if (customers.find(c => c.email === email)) {
        showNotification('Email already registered', 'error');
        return;
    }
    
    // Create customer
    const customer = {
        id: Date.now(),
        name: name,
        email: email,
        phone: phone,
        password: password,
        address: address,
        platform: platform,
        balanceNGN: platform === 'trading' || platform === 'pilgrim' ? 0 : initialBalance,
        balanceUSD: platform === 'trading' || platform === 'pilgrim' ? initialBalance : 0,
        balanceBTC: 0,
        balanceUSDT: 0,
        balancePLG: 0,
        status: 'active',
        joinDate: new Date().toISOString(),
        passport: passport ? passport.name : null,
        idDocument: idDocument ? idDocument.name : null,
        transactions: []
    };
    
    customers.push(customer);
    
    // Add transaction
    addTransaction(customer.id, 'credit', initialBalance, platform === 'trading' || platform === 'pilgrim' ? 'USD' : 'NGN', 'Initial deposit by admin');
    
    saveToStorage();
    updateDashboard();
    
    // Clear form
    document.getElementById('newCustomerForm').reset();
    
    showNotification('Customer registered successfully!', 'success');
}

// ==================== EDIT CUSTOMER ====================
function editCustomer(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    document.getElementById('editCustomerId').value = customer.id;
    document.getElementById('editCustomerName').value = customer.name;
    document.getElementById('editCustomerEmail').value = customer.email;
    document.getElementById('editCustomerPhone').value = customer.phone;
    document.getElementById('editCustomerAddress').value = customer.address || '';
    document.getElementById('editCustomerBalance').value = customer.balanceNGN || 0;
    document.getElementById('editCustomerBalanceUSD').value = customer.balanceUSD || 0;
    document.getElementById('editCustomerStatus').value = customer.status;
    
    document.getElementById('editCustomerModal').style.display = 'flex';
}

function saveCustomerChanges() {
    const customerId = parseInt(document.getElementById('editCustomerId').value);
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    customer.name = document.getElementById('editCustomerName').value;
    customer.email = document.getElementById('editCustomerEmail').value;
    customer.phone = document.getElementById('editCustomerPhone').value;
    customer.address = document.getElementById('editCustomerAddress').value;
    customer.balanceNGN = parseFloat(document.getElementById('editCustomerBalance').value) || 0;
    customer.balanceUSD = parseFloat(document.getElementById('editCustomerBalanceUSD').value) || 0;
    customer.status = document.getElementById('editCustomerStatus').value;
    
    saveToStorage();
    updateDashboard();
    closeModals();
    
    showNotification('Customer updated successfully!', 'success');
}

function toggleCustomerStatus(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    if (customer.status === 'blocked') {
        customer.status = 'active';
        showNotification('Customer unblocked', 'success');
    } else {
        customer.status = 'blocked';
        showNotification('Customer blocked', 'warning');
    }
    
    saveToStorage();
    updateDashboard();
}

function deleteCustomer(customerId) {
    if (!confirm('Are you sure you want to delete this customer?')) return;
    
    customers = customers.filter(c => c.id !== customerId);
    transactions = transactions.filter(t => t.customerId !== customerId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Customer deleted', 'warning');
}

// ==================== CREDIT/DEBIT ACCOUNT ====================
function creditAccount() {
    const customerId = parseInt(document.getElementById('creditCustomer').value);
    const amount = parseFloat(document.getElementById('creditAmount').value);
    const currency = document.getElementById('creditCurrency').value;
    const description = document.getElementById('creditDescription').value;
    
    if (!customerId || !amount) {
        showNotification('Please select customer and enter amount', 'error');
        return;
    }
    
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // Credit customer
    switch (currency) {
        case 'NGN':
            customer.balanceNGN += amount;
            break;
        case 'USD':
            customer.balanceUSD += amount;
            break;
        case 'BTC':
            customer.balanceBTC += amount;
            break;
        case 'USDT':
            customer.balanceUSDT += amount;
            break;
    }
    
    // Add transaction
    addTransaction(customerId, 'credit', amount, currency, description || 'Manual credit by admin');
    
    saveToStorage();
    updateDashboard();
    
    showNotification(`Credited ${formatCurrency(amount)} ${currency} to ${customer.name}`, 'success');
    document.getElementById('creditForm').reset();
}

function debitAccount() {
    const customerId = parseInt(document.getElementById('debitCustomer').value);
    const amount = parseFloat(document.getElementById('debitAmount').value);
    const currency = document.getElementById('debitCurrency').value;
    const description = document.getElementById('debitDescription').value;
    
    if (!customerId || !amount) {
        showNotification('Please select customer and enter amount', 'error');
        return;
    }
    
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // Check balance
    let currentBalance = 0;
    switch (currency) {
        case 'NGN':
            currentBalance = customer.balanceNGN || 0;
            break;
        case 'USD':
            currentBalance = customer.balanceUSD || 0;
            break;
        case 'BTC':
            currentBalance = customer.balanceBTC || 0;
            break;
        case 'USDT':
            currentBalance = customer.balanceUSDT || 0;
            break;
    }
    
    if (currentBalance < amount) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    // Debit customer
    switch (currency) {
        case 'NGN':
            customer.balanceNGN -= amount;
            adminWallet.NGN += amount;
            break;
        case 'USD':
            customer.balanceUSD -= amount;
            adminWallet.USD += amount;
            break;
        case 'BTC':
            customer.balanceBTC -= amount;
            adminWallet.BTC += amount;
            break;
        case 'USDT':
            customer.balanceUSDT -= amount;
            adminWallet.USDT += amount;
            break;
    }
    
    // Add transaction
    addTransaction(customerId, 'debit', amount, currency, description || 'Manual debit by admin');
    
    saveToStorage();
    updateDashboard();
    
    showNotification(`Debited ${formatCurrency(amount)} ${currency} from ${customer.name}`, 'success');
    document.getElementById('debitForm').reset();
}

function updateCustomerDropdowns() {
    const creditSelect = document.getElementById('creditCustomer');
    const debitSelect = document.getElementById('debitCustomer');
    
    if (!creditSelect || !debitSelect) return;
    
    const options = '<option value="">Select customer</option>' + 
        customers.map(c => `<option value="${c.id}">${c.name} (${getPlatformName(c.platform)})</option>`).join('');
    
    creditSelect.innerHTML = options;
    debitSelect.innerHTML = options;
}

// ==================== APPROVALS ====================
function showApprovalTab(tabName) {
    const tabs = document.querySelectorAll('.approval-tab');
    tabs.forEach(tab => tab.style.display = 'none');
    
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => btn.classList.remove('active'));
    
    document.getElementById(tabName + 'Tab').style.display = 'block';
    event.target.classList.add('active');
}

function renderPendingApprovals() {
    renderPendingRegistrations();
    renderPendingDeposits();
    renderPendingWithdrawals();
    renderPendingPayments();
}

function renderPendingRegistrations() {
    const container = document.getElementById('pendingRegistrations');
    
    if (pendingRegistrations.length === 0) {
        container.innerHTML = '<p class="empty-state">No pending registrations</p>';
        return;
    }
    
    container.innerHTML = pendingRegistrations.map(reg => {
        const customer = customers.find(c => c.id === reg.customerId);
        return `
            <div class="approval-item">
                <div class="approval-item-header">
                    <h4>${customer?.name || 'Unknown'}</h4>
                    <span class="status-badge pending">Pending</span>
                </div>
                <div class="approval-item-details">
                    <p><strong>Email:</strong> ${customer?.email}</p>
                    <p><strong>Phone:</strong> ${customer?.phone}</p>
                    <p><strong>Platform:</strong> ${getPlatformName(customer?.platform)}</p>
                    <p><strong>Date:</strong> ${new Date(reg.date).toLocaleDateString()}</p>
                </div>
                <div class="approval-actions">
                    <button class="btn-approve" onclick="approveRegistration(${reg.id})">✅ Approve</button>
                    <button class="btn-reject" onclick="rejectRegistration(${reg.id})">❌ Reject</button>
                </div>
            </div>
        `;
    }).join('');
}

function approveRegistration(regId) {
    const reg = pendingRegistrations.find(r => r.id === regId);
    if (!reg) return;
    
    const customer = customers.find(c => c.id === reg.customerId);
    if (customer) {
        customer.status = 'active';
    }
    
    pendingRegistrations = pendingRegistrations.filter(r => r.id !== regId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Registration approved!', 'success');
}

function rejectRegistration(regId) {
    pendingRegistrations = pendingRegistrations.filter(r => r.id !== regId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Registration rejected', 'warning');
}

function renderPendingDeposits() {
    const container = document.getElementById('pendingDeposits');
    
    if (pendingDeposits.length === 0) {
        container.innerHTML = '<p class="empty-state">No pending deposits</p>';
        return;
    }
    
    container.innerHTML = pendingDeposits.map(deposit => {
        const customer = customers.find(c => c.id === deposit.customerId);
        return `
            <div class="approval-item">
                <div class="approval-item-header">
                    <h4>Deposit Request - ${customer?.name || 'Unknown'}</h4>
                    <span class="status-badge pending">Pending</span>
                </div>
                <div class="approval-item-details">
                    <p><strong>Amount:</strong> ${formatCurrency(deposit.amount)} ${deposit.currency}</p>
                    <p><strong>Method:</strong> ${deposit.method}</p>
                    <p><strong>Date:</strong> ${new Date(deposit.date).toLocaleDateString()}</p>
                </div>
                <div class="approval-actions">
                    <button class="btn-approve" onclick="approveDeposit(${deposit.id})">✅ Approve</button>
                    <button class="btn-reject" onclick="rejectDeposit(${deposit.id})">❌ Reject</button>
                </div>
            </div>
        `;
    }).join('');
}

function approveDeposit(depositId) {
    const deposit = pendingDeposits.find(d => d.id === depositId);
    if (!deposit) return;
    
    const customer = customers.find(c => c.id === deposit.customerId);
    if (customer) {
        switch (deposit.currency) {
            case 'NGN':
                customer.balanceNGN += deposit.amount;
                break;
            case 'USD':
                customer.balanceUSD += deposit.amount;
                break;
            case 'BTC':
                customer.balanceBTC += deposit.amount;
                break;
            case 'USDT':
                customer.balanceUSDT += deposit.amount;
                break;
        }
    }
    
    pendingDeposits = pendingDeposits.filter(d => d.id !== depositId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Deposit approved!', 'success');
}

function rejectDeposit(depositId) {
    pendingDeposits = pendingDeposits.filter(d => d.id !== depositId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Deposit rejected', 'warning');
}

function renderPendingWithdrawals() {
    const container = document.getElementById('pendingWithdrawals');
    
    if (pendingWithdrawals.length === 0) {
        container.innerHTML = '<p class="empty-state">No pending withdrawals</p>';
        return;
    }
    
    container.innerHTML = pendingWithdrawals.map(withdrawal => {
        const customer = customers.find(c => c.id === withdrawal.customerId);
        return `
            <div class="approval-item">
                <div class="approval-item-header">
                    <h4>Withdrawal Request - ${customer?.name || 'Unknown'}</h4>
                    <span class="status-badge pending">Pending</span>
                </div>
                <div class="approval-item-details">
                    <p><strong>Amount:</strong> ${formatCurrency(withdrawal.amount)} ${withdrawal.currency}</p>
                    <p><strong>Destination:</strong> ${withdrawal.destination}</p>
                    <p><strong>Date:</strong> ${new Date(withdrawal.date).toLocaleDateString()}</p>
                </div>
                <div class="approval-actions">
                    <button class="btn-approve" onclick="approveWithdrawal(${withdrawal.id})">✅ Approve</button>
                    <button class="btn-reject" onclick="rejectWithdrawal(${withdrawal.id})">❌ Reject</button>
                </div>
            </div>
        `;
    }).join('');
}

function approveWithdrawal(withdrawalId) {
    const withdrawal = pendingWithdrawals.find(w => w.id === withdrawalId);
    if (!withdrawal) return;
    
    pendingWithdrawals = pendingWithdrawals.filter(w => w.id !== withdrawalId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Withdrawal approved!', 'success');
}

function rejectWithdrawal(withdrawalId) {
    const withdrawal = pendingWithdrawals.find(w => w.id === withdrawalId);
    if (!withdrawal) return;
    
    // Refund to customer
    const customer = customers.find(c => c.id === withdrawal.customerId);
    if (customer) {
        switch (withdrawal.currency) {
            case 'NGN':
                customer.balanceNGN += withdrawal.amount;
                break;
            case 'USD':
                customer.balanceUSD += withdrawal.amount;
                break;
            case 'BTC':
                customer.balanceBTC += withdrawal.amount;
                break;
            case 'USDT':
                customer.balanceUSDT += withdrawal.amount;
                break;
        }
    }
    
    pendingWithdrawals = pendingWithdrawals.filter(w => w.id !== withdrawalId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Withdrawal rejected, amount refunded', 'warning');
}

function renderPendingPayments() {
    const container = document.getElementById('pendingPayments');
    
    if (pendingPayments.length === 0) {
        container.innerHTML = '<p class="empty-state">No pending payments</p>';
        return;
    }
    
    container.innerHTML = pendingPayments.map(payment => `
        <div class="approval-item">
            <div class="approval-item-header">
                <h4>Payment - ${payment.name}</h4>
                <span class="status-badge pending">Pending</span>
            </div>
            <div class="approval-item-details">
                <p><strong>Amount:</strong> ${formatCurrency(payment.amount)} ${payment.currency}</p>
                <p><strong>Bank:</strong> ${payment.bank}</p>
                <p><strong>Account:</strong> ${payment.accountNumber}</p>
                <p><strong>Date:</strong> ${new Date(payment.date).toLocaleDateString()}</p>
            </div>
            <div class="approval-actions">
                <button class="btn-approve" onclick="approvePayment(${payment.id})">✅ Approve</button>
                <button class="btn-reject" onclick="rejectPayment(${payment.id})">❌ Reject</button>
            </div>
        </div>
    `).join('');
}

function approvePayment(paymentId) {
    const payment = pendingPayments.find(p => p.id === paymentId);
    if (!payment) return;
    
    pendingPayments = pendingPayments.filter(p => p.id !== paymentId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Payment approved!', 'success');
}

function rejectPayment(paymentId) {
    pendingPayments = pendingPayments.filter(p => p.id !== paymentId);
    
    saveToStorage();
    updateDashboard();
    
    showNotification('Payment rejected', 'warning');
}

// ==================== TRANSACTIONS ====================
function renderTransactionsTable() {
    const tbody = document.getElementById('transactionsTableBody');
    
    if (transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No transactions</td></tr>';
        return;
    }
    
    tbody.innerHTML = transactions.slice(0, 50).map(transaction => {
        const customer = customers.find(c => c.id === transaction.customerId);
        return `
            <tr>
                <td>#${transaction.id}</td>
                <td>${new Date(transaction.date).toLocaleDateString()}</td>
                <td>${customer?.name || 'Unknown'}</td>
                <td>${transaction.type}</td>
                <td>${formatCurrency(transaction.amount)} ${transaction.currency}</td>
                <td>${transaction.method}</td>
                <td><span class="status-badge active">${transaction.status}</span></td>
                <td>
                    <button class="btn-action" onclick="viewTransaction(${transaction.id})">👁️ View</button>
                </td>
            </tr>
        `;
    }).join('');
}

function addTransaction(customerId, type, amount, currency, description, method = 'Admin') {
    const transaction = {
        id: Date.now(),
        customerId: customerId,
        type: type,
        amount: amount,
        currency: currency,
        description: description,
        method: method,
        status: 'completed',
        date: new Date().toISOString()
    };
    
    transactions.unshift(transaction);
    
    // Update admin wallet for credits
    if (type === 'credit' && method !== 'Admin') {
        switch (currency) {
            case 'NGN':
                adminWallet.NGN += amount;
                break;
            case 'USD':
                adminWallet.USD += amount;
                break;
            case 'BTC':
                adminWallet.BTC += amount;
                break;
            case 'USDT':
                adminWallet.USDT += amount;
                break;
        }
    }
}

function filterTransactions() {
    renderTransactionsTable();
}

function filterTransactionsByDate() {
    renderTransactionsTable();
}

function viewTransaction(transactionId) {
    const transaction = transactions.find(t => t.id === transactionId);
    if (!transaction) return;
    
    alert(`
        Transaction Details:
        ID: ${transaction.id}
        Type: ${transaction.type}
        Amount: ${formatCurrency(transaction.amount)} ${transaction.currency}
        Description: ${transaction.description}
        Method: ${transaction.method}
        Status: ${transaction.status}
        Date: ${new Date(transaction.date).toLocaleString()}
    `);
}

// ==================== MESSAGES ====================
function renderMessages() {
    const container = document.getElementById('messagesList');
    
    if (messages.length === 0) {
        container.innerHTML = '<p class="empty-state">No messages</p>';
        return;
    }
    
    container.innerHTML = messages.map(message => {
        const customer = customers.find(c => c.id === message.customerId);
        return `
            <div class="message-item">
                <div class="message-header">
                    <span class="message-sender">${customer?.name || 'Unknown'}</span>
                    <span class="message-date">${new Date(message.date).toLocaleDateString()}</span>
                </div>
                <div class="message-content">${message.content}</div>
            </div>
        `;
    }).join('');
}

// ==================== MODALS ====================
function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
}

// ==================== UTILITY FUNCTIONS ====================
function formatCurrency(amount) {
    return parseFloat(amount).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// ==================== STORAGE ====================
function saveToStorage() {
    localStorage.setItem('adminCustomers', JSON.stringify(customers));
    localStorage.setItem('adminTransactions', JSON.stringify(transactions));
    localStorage.setItem('adminPendingRegistrations', JSON.stringify(pendingRegistrations));
    localStorage.setItem('adminPendingDeposits', JSON.stringify(pendingDeposits));
    localStorage.setItem('adminPendingWithdrawals', JSON.stringify(pendingWithdrawals));
    localStorage.setItem('adminPendingPayments', JSON.stringify(pendingPayments));
    localStorage.setItem('adminMessages', JSON.stringify(messages));
    localStorage.setItem('adminWallet', JSON.stringify(adminWallet));
}

function loadFromStorage() {
    const storedCustomers = localStorage.getItem('adminCustomers');
    if (storedCustomers) {
        customers = JSON.parse(storedCustomers);
    }
    
    const storedTransactions = localStorage.getItem('adminTransactions');
    if (storedTransactions) {
        transactions = JSON.parse(storedTransactions);
    }
    
    const storedRegistrations = localStorage.getItem('adminPendingRegistrations');
    if (storedRegistrations) {
        pendingRegistrations = JSON.parse(storedRegistrations);
    }
    
    const storedDeposits = localStorage.getItem('adminPendingDeposits');
    if (storedDeposits) {
        pendingDeposits = JSON.parse(storedDeposits);
    }
    
    const storedWithdrawals = localStorage.getItem('adminPendingWithdrawals');
    if (storedWithdrawals) {
        pendingWithdrawals = JSON.parse(storedWithdrawals);
    }
    
    const storedPayments = localStorage.getItem('adminPendingPayments');
    if (storedPayments) {
        pendingPayments = JSON.parse(storedPayments);
    }
    
    const storedMessages = localStorage.getItem('adminMessages');
    if (storedMessages) {
        messages = JSON.parse(storedMessages);
    }
    
    const storedWallet = localStorage.getItem('adminWallet');
    if (storedWallet) {
        adminWallet = JSON.parse(storedWallet);
    }
}

function initializeSampleData() {
    // Add sample customers
    customers = [
        {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            phone: '+2348012345678',
            password: 'password123',
            address: 'Lagos, Nigeria',
            platform: 'commodity',
            balanceNGN: 50000,
            balanceUSD: 0,
            balanceBTC: 0,
            balanceUSDT: 0,
            balancePLG: 0,
            status: 'active',
            joinDate: new Date().toISOString(),
            passport: null,
            idDocument: null,
            transactions: []
        },
        {
            id: 2,
            name: 'Jane Smith',
            email: 'jane@example.com',
            phone: '+2348023456789',
            password: 'password123',
            address: 'Abuja, Nigeria',
            platform: 'pilgrim',
            balanceNGN: 0,
            balanceUSD: 1000,
            balanceBTC: 0.05,
            balanceUSDT: 100,
            balancePLG: 1000,
            status: 'active',
            joinDate: new Date().toISOString(),
            passport: null,
            idDocument: null,
            transactions: []
        }
    ];
    
    // Add sample transactions
    transactions = [
        {
            id: 1,
            customerId: 1,
            type: 'credit',
            amount: 50000,
            currency: 'NGN',
            description: 'Initial deposit',
            method: 'Admin',
            status: 'completed',
            date: new Date().toISOString()
        },
        {
            id: 2,
            customerId: 2,
            type: 'credit',
            amount: 1000,
            currency: 'USD',
            description: 'Initial deposit',
            method: 'Admin',
            status: 'completed',
            date: new Date().toISOString()
        }
    ];
    
    saveToStorage();
}

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModals();
    }
}