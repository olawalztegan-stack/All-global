// ===================================
// UNIFIED WALLET SYSTEM
// Links all platforms together
// ===================================

class UnifiedWallet {
    constructor() {
        this.balance = 0;
        this.transactions = [];
        this.platforms = {
            ninjatech: { balance: 0, transactions: [] },
            sportsBetting: { balance: 0, transactions: [] },
            globalCount: { balance: 0, transactions: [] },
            commodity: { balance: 0, transactions: [] }
        };
        this.loadFromStorage();
    }

    // ===================================
    // STORAGE METHODS
    // ===================================

    saveToStorage() {
        saveToStorage('unifiedWallet', {
            balance: this.balance,
            transactions: this.transactions,
            platforms: this.platforms
        });
    }

    loadFromStorage() {
        const data = getFromStorage('unifiedWallet');
        if (data) {
            this.balance = data.balance || 0;
            this.transactions = data.transactions || [];
            this.platforms = data.platforms || this.platforms;
        }
    }

    // ===================================
    // DEPOSIT METHODS
    // ===================================

    deposit(amount, method, platform = 'unified', metadata = {}) {
        const transaction = {
            id: generateTransactionId(),
            type: 'deposit',
            platform: platform,
            amount: amount,
            method: method,
            status: 'completed',
            timestamp: new Date().toISOString(),
            metadata: metadata
        };

        if (platform === 'unified') {
            this.balance += amount;
        } else if (this.platforms[platform]) {
            this.platforms[platform].balance += amount;
        }

        this.transactions.unshift(transaction);
        this.saveToStorage();
        return transaction;
    }

    // ===================================
    // WITHDRAWAL METHODS
    // ===================================

    withdraw(amount, method, platform = 'unified', metadata = {}) {
        const fee = calculateTransactionFee(amount);
        const netAmount = amount - fee;

        if (platform === 'unified') {
            if (this.balance < amount) {
                return { success: false, message: 'Insufficient balance' };
            }
            this.balance -= amount;
        } else if (this.platforms[platform]) {
            if (this.platforms[platform].balance < amount) {
                return { success: false, message: 'Insufficient balance' };
            }
            this.platforms[platform].balance -= amount;
        }

        const transaction = {
            id: generateTransactionId(),
            type: 'withdrawal',
            platform: platform,
            amount: amount,
            fee: fee,
            netAmount: netAmount,
            method: method,
            status: 'completed',
            timestamp: new Date().toISOString(),
            metadata: metadata
        };

        this.transactions.unshift(transaction);
        this.saveToStorage();
        return { success: true, transaction: transaction };
    }

    // ===================================
    // TRANSFER METHODS
    // ===================================

    transfer(amount, fromPlatform, toPlatform, metadata = {}) {
        const fee = calculateTransactionFee(amount);
        const netAmount = amount - fee;

        // Check source balance
        if (fromPlatform === 'unified') {
            if (this.balance < amount) {
                return { success: false, message: 'Insufficient balance' };
            }
            this.balance -= amount;
        } else if (this.platforms[fromPlatform]) {
            if (this.platforms[fromPlatform].balance < amount) {
                return { success: false, message: 'Insufficient balance' };
            }
            this.platforms[fromPlatform].balance -= amount;
        }

        // Add to destination
        if (toPlatform === 'unified') {
            this.balance += netAmount;
        } else if (this.platforms[toPlatform]) {
            this.platforms[toPlatform].balance += netAmount;
        }

        const transaction = {
            id: generateTransactionId(),
            type: 'transfer',
            fromPlatform: fromPlatform,
            toPlatform: toPlatform,
            amount: amount,
            fee: fee,
            netAmount: netAmount,
            status: 'completed',
            timestamp: new Date().toISOString(),
            metadata: metadata
        };

        this.transactions.unshift(transaction);
        this.saveToStorage();
        return { success: true, transaction: transaction };
    }

    // ===================================
    // BALANCE METHODS
    // ===================================

    getBalance(platform = 'unified') {
        if (platform === 'unified') {
            return this.balance;
        } else if (this.platforms[platform]) {
            return this.platforms[platform].balance;
        }
        return 0;
    }

    getTotalBalance() {
        let total = this.balance;
        for (const platform in this.platforms) {
            total += this.platforms[platform].balance;
        }
        return total;
    }

    getPlatformBalances() {
        return {
            unified: this.balance,
            ninjatech: this.platforms.ninjatech.balance,
            sportsBetting: this.platforms.sportsBetting.balance,
            globalCount: this.platforms.globalCount.balance,
            commodity: this.platforms.commodity.balance
        };
    }

    // ===================================
    // TRANSACTION METHODS
    // ===================================

    getTransactions(platform = 'all', limit = 50) {
        let filtered = this.transactions;
        
        if (platform !== 'all') {
            filtered = this.transactions.filter(t => t.platform === platform || t.fromPlatform === platform || t.toPlatform === platform);
        }
        
        return filtered.slice(0, limit);
    }

    getTransactionById(id) {
        return this.transactions.find(t => t.id === id);
    }

    getTransactionHistory(days = 30) {
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        
        return this.transactions.filter(t => new Date(t.timestamp) >= cutoff);
    }

    // ===================================
    // STATISTICS
    // ===================================

    getTotalDeposits(platform = 'all') {
        const transactions = platform === 'all' 
            ? this.transactions 
            : this.transactions.filter(t => t.platform === platform);
        
        return transactions
            .filter(t => t.type === 'deposit')
            .reduce((sum, t) => sum + t.amount, 0);
    }

    getTotalWithdrawals(platform = 'all') {
        const transactions = platform === 'all' 
            ? this.transactions 
            : this.transactions.filter(t => t.platform === platform);
        
        return transactions
            .filter(t => t.type === 'withdrawal')
            .reduce((sum, t) => sum + t.amount, 0);
    }

    getTotalFees(platform = 'all') {
        const transactions = platform === 'all' 
            ? this.transactions 
            : this.transactions.filter(t => t.platform === platform);
        
        return transactions
            .reduce((sum, t) => sum + (t.fee || 0), 0);
    }

    getTransactionSummary(platform = 'all') {
        const transactions = platform === 'all' 
            ? this.transactions 
            : this.transactions.filter(t => t.platform === platform);
        
        const summary = {
            total: transactions.length,
            deposits: 0,
            withdrawals: 0,
            transfers: 0,
            totalAmount: 0,
            totalFees: 0
        };

        transactions.forEach(t => {
            if (t.type === 'deposit') summary.deposits++;
            else if (t.type === 'withdrawal') summary.withdrawals++;
            else if (t.type === 'transfer') summary.transfers++;
            
            summary.totalAmount += t.amount;
            summary.totalFees += t.fee || 0;
        });

        return summary;
    }

    // ===================================
    // ADMIN METHODS
    // ===================================

    adminAddBalance(platform, amount, reason) {
        if (platform === 'unified') {
            this.balance += amount;
        } else if (this.platforms[platform]) {
            this.platforms[platform].balance += amount;
        }

        const transaction = {
            id: generateTransactionId(),
            type: 'admin_adjustment',
            platform: platform,
            amount: amount,
            status: 'completed',
            timestamp: new Date().toISOString(),
            metadata: {
                reason: reason,
                admin: true
            }
        };

        this.transactions.unshift(transaction);
        this.saveToStorage();
        return transaction;
    }

    adminDeductBalance(platform, amount, reason) {
        if (platform === 'unified') {
            if (this.balance < amount) {
                return { success: false, message: 'Insufficient balance' };
            }
            this.balance -= amount;
        } else if (this.platforms[platform]) {
            if (this.platforms[platform].balance < amount) {
                return { success: false, message: 'Insufficient balance' };
            }
            this.platforms[platform].balance -= amount;
        }

        const transaction = {
            id: generateTransactionId(),
            type: 'admin_adjustment',
            platform: platform,
            amount: -amount,
            status: 'completed',
            timestamp: new Date().toISOString(),
            metadata: {
                reason: reason,
                admin: true
            }
        };

        this.transactions.unshift(transaction);
        this.saveToStorage();
        return { success: true, transaction: transaction };
    }

    // ===================================
    // RESET & CLEAR
    // ===================================

    reset() {
        this.balance = 0;
        this.transactions = [];
        this.platforms = {
            ninjatech: { balance: 0, transactions: [] },
            sportsBetting: { balance: 0, transactions: [] },
            globalCount: { balance: 0, transactions: [] },
            commodity: { balance: 0, transactions: [] }
        };
        this.saveToStorage();
    }

    clearTransactions(platform = 'all') {
        if (platform === 'all') {
            this.transactions = [];
        } else {
            this.transactions = this.transactions.filter(t => t.platform !== platform);
        }
        this.saveToStorage();
    }
}

// ===================================
// GLOBAL INSTANCE
// ===================================

const unifiedWallet = new UnifiedWallet();

// ===================================
// HELPER FUNCTIONS FOR UI
// ===================================

function displayWalletBalance(platform = 'unified') {
    const balance = unifiedWallet.getBalance(platform);
    return formatCurrency(balance);
}

function displayTotalBalance() {
    return formatCurrency(unifiedWallet.getTotalBalance());
}

function displayPlatformBalances() {
    return unifiedWallet.getPlatformBalances();
}

function displayTransactionHistory(platform = 'all', limit = 10) {
    const transactions = unifiedWallet.getTransactions(platform, limit);
    return transactions.map(t => ({
        id: t.id,
        type: t.type,
        amount: formatCurrency(t.amount),
        platform: t.platform,
        status: t.status,
        date: formatDateTime(t.timestamp)
    }));
}

// ===================================
// INITIALIZE
// ===================================

console.log('Unified Wallet System loaded');
console.log('Current total balance:', displayTotalBalance());