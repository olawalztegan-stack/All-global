// ===================================
// SHARED JAVASCRIPT FOR ALL PLATFORMS
// Global Trading Platforms - Common Utilities
// ===================================

// ===================================
// CURRENCY FORMATTING
// ===================================

function formatCurrency(amount, currency = '₦') {
    if (typeof amount !== 'number') {
        amount = parseFloat(amount) || 0;
    }
    return currency + amount.toLocaleString('en-NG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// ===================================
// DATE FORMATTING
// ===================================

function formatDate(date) {
    const d = new Date(date);
    return d.toLocaleDateString('en-NG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatDateTime(date) {
    const d = new Date(date);
    return d.toLocaleString('en-NG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatTime(date) {
    const d = new Date(date);
    return d.toLocaleTimeString('en-NG', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

// ===================================
// STORAGE MANAGEMENT
// ===================================

function saveToStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error('Error saving to storage:', error);
        return false;
    }
}

function getFromStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Error reading from storage:', error);
        return null;
    }
}

function removeFromStorage(key) {
    try {
        localStorage.removeItem(key);
        return true;
    } catch (error) {
        console.error('Error removing from storage:', error);
        return false;
    }
}

// ===================================
// NOTIFICATIONS
// ===================================

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(n => n.remove());

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification alert alert-${type} fade-in`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 400px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    `;
    notification.innerHTML = `
        <div class="flex-between">
            <span>${message}</span>
            <button class="btn btn-sm" onclick="this.parentElement.parentElement.remove()">✕</button>
        </div>
    `;

    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 500);
    }, 5000);

    // Click to dismiss
    notification.addEventListener('click', () => notification.remove());
}

// ===================================
// VALIDATION
// ===================================

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\d\s\+\-\(\)]+$/;
    return re.test(phone) && phone.length >= 10;
}

function validateAmount(amount, min = 0) {
    const num = parseFloat(amount);
    return !isNaN(num) && num >= min;
}

function validatePassword(password) {
    return password && password.length >= 6;
}

// ===================================
// MODAL FUNCTIONS
// ===================================

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

function createModal(title, content, footer = '') {
    const modalId = 'modal-' + Date.now();
    const modal = document.createElement('div');
    modal.id = modalId;
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${title}</h3>
                <button class="btn btn-sm" onclick="hideModal('${modalId}')">✕</button>
            </div>
            <div class="modal-body">${content}</div>
            ${footer ? `<div class="modal-footer">${footer}</div>` : ''}
        </div>
    `;
    document.body.appendChild(modal);
    return modalId;
}

// ===================================
// LOADING STATES
// ===================================

function showLoading(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = `
            <div class="flex-center" style="padding: 40px;">
                <div class="spinner"></div>
            </div>
        `;
    }
}

function hideLoading(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
        const spinner = container.querySelector('.spinner');
        if (spinner) {
            spinner.remove();
        }
    }
}

// ===================================
// COPY TO CLIPBOARD
// ===================================

function copyToClipboard(text, successMessage = 'Copied to clipboard!') {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text)
            .then(() => showNotification(successMessage, 'success'))
            .catch(() => fallbackCopyToClipboard(text, successMessage));
    } else {
        fallbackCopyToClipboard(text, successMessage);
    }
}

function fallbackCopyToClipboard(text, successMessage) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.select();
    try {
        document.execCommand('copy');
        showNotification(successMessage, 'success');
    } catch (err) {
        showNotification('Failed to copy', 'error');
    }
    document.body.removeChild(textArea);
}

// ===================================
// RANDOM GENERATORS
// ===================================

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function generateTransactionId() {
    return 'TXN' + Date.now() + Math.floor(Math.random() * 1000);
}

function generateReferenceCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 10; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// ===================================
// WALLET UTILITIES
// ===================================

function calculateTransactionFee(amount, percentage = 0.02) {
    return amount * percentage;
}

function calculateNetAmount(amount, percentage = 0.02) {
    return amount - calculateTransactionFee(amount, percentage);
}

function processWalletTransfer(fromWallet, toWallet, amount, fee = 0.02) {
    const transactionFee = amount * fee;
    const netAmount = amount - transactionFee;

    if (fromWallet.balance < amount) {
        return {
            success: false,
            message: 'Insufficient balance'
        };
    }

    fromWallet.balance -= amount;
    toWallet.balance += netAmount;

    return {
        success: true,
        fee: transactionFee,
        netAmount: netAmount,
        message: `Transfer successful. Fee: ${formatCurrency(transactionFee)}`
    };
}

// ===================================
// CHART DATA GENERATION
// ===================================

function generateChartData(points, min, max) {
    const data = [];
    for (let i = 0; i < points; i++) {
        data.push({
            x: i,
            y: Math.random() * (max - min) + min
        });
    }
    return data;
}

function generateTimeSeries(days, baseValue, volatility = 0.02) {
    const data = [];
    let currentValue = baseValue;
    const now = new Date();

    for (let i = days; i >= 0; i--) {
        const change = (Math.random() - 0.5) * 2 * volatility;
        currentValue = currentValue * (1 + change);
        
        const date = new Date(now);
        date.setDate(date.getDate() - i);

        data.push({
            date: date.toISOString().split('T')[0],
            value: currentValue,
            change: change
        });
    }
    return data;
}

// ===================================
// PAGE NAVIGATION
// ===================================

function navigateTo(url) {
    window.location.href = url;
}

function openInNewTab(url) {
    window.open(url, '_blank');
}

function getCurrentPage() {
    const path = window.location.pathname;
    return path.split('/').pop() || 'index.html';
}

// ===================================
// PLATFORM CONSTANTS
// ===================================

const PLATFORMS = {
    NINJATECH: {
        name: 'NinjaTech Enhanced Trading',
        code: 'NT',
        color: '#8b5cf6'
    },
    SPORTS_BETTING: {
        name: 'Sports Betting & Casino',
        code: 'SB',
        color: '#f59e0b'
    },
    GLOBAL_COUNT: {
        name: 'Global Count Trading',
        code: 'GC',
        color: '#10b981'
    },
    COMMODITY: {
        name: 'Global Commodity Market',
        code: 'CM',
        color: '#3b82f6'
    }
};

const BANKS = [
    { name: 'Access Bank', code: 'AB' },
    { name: 'GTBank', code: 'GT' },
    { name: 'UBA', code: 'UB' },
    { name: 'First Bank', code: 'FB' },
    { name: 'Zenith Bank', code: 'ZB' },
    { name: 'OPay', code: 'OP' },
    { name: 'Palmpay', code: 'PP' },
    { name: 'Moniepoint', code: 'MP' },
    { name: 'Kuda Bank', code: 'KB' },
    { name: 'Wema Bank', code: 'WB' },
    { name: 'Sterling Bank', code: 'SB' },
    { name: 'Fidelity Bank', code: 'FB' }
];

// ===================================
// INITIALIZE
// ===================================

document.addEventListener('DOMContentLoaded', () => {
    // Close modals on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const activeModal = document.querySelector('.modal.active');
            if (activeModal) {
                activeModal.classList.remove('active');
                document.body.style.overflow = 'auto';
            }
        }
    });

    // Close modals on outside click
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
                document.body.style.overflow = 'auto';
            }
        });
    });

    console.log('Common utilities loaded successfully');
});

// ===================================
// EXPORTS (for use in other files)
// ===================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        formatCurrency,
        formatDate,
        formatDateTime,
        saveToStorage,
        getFromStorage,
        removeFromStorage,
        showNotification,
        validateEmail,
        validatePhone,
        validateAmount,
        validatePassword,
        showModal,
        hideModal,
        createModal,
        showLoading,
        hideLoading,
        copyToClipboard,
        generateId,
        generateTransactionId,
        generateReferenceCode,
        calculateTransactionFee,
        calculateNetAmount,
        processWalletTransfer,
        generateChartData,
        generateTimeSeries,
        navigateTo,
        openInNewTab,
        getCurrentPage,
        PLATFORMS,
        BANKS
    };
}