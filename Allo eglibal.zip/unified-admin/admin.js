// ===================================
// UNIFIED ADMIN SYSTEM JAVASCRIPT
// Global Trading Platforms - Admin Dashboard
// ===================================

// ===================================
// ADMIN CREDENTIALS
// ===================================

const ADMIN_CREDENTIALS = {
    // Unified Admin (Master)
    unified: {
        email: 'admin@globaltrading.com',
        password: 'MasterAdmin@2024',
        name: 'Super Admin'
    },
    
    // NinjaTech Enhanced Trading
    ninjatech: {
        email: 'admin@ninjatech.com',
        password: 'NinjaTech@2024',
        name: 'NinjaTech Admin'
    },
    
    // Sports Betting & Casino
    'sports-betting': {
        email: 'admin@sportsbetting.com',
        password: 'SportsBetting@2024',
        name: 'Sports Betting Admin'
    },
    
    // Global Count Trading
    'global-count': {
        email: 'adeganglobal@gmail.com',
        password: 'admin123',
        name: 'Global Count Admin'
    },
    
    // Global Commodity Market
    commodity: {
        email: 'admin@commoditymarket.com',
        password: 'CommodityMarket@2024',
        name: 'Commodity Market Admin'
    }
};

// ===================================
// STATE MANAGEMENT
// ===================================

let currentPlatform = 'unified';
let currentAdmin = null;
let isLoggedIn = false;

// ===================================
// PLATFORM SELECTION
// ===================================

document.querySelectorAll('.platform-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        // Remove selected class from all buttons
        document.querySelectorAll('.platform-btn').forEach(b => b.classList.remove('selected'));
        
        // Add selected class to clicked button
        this.classList.add('selected');
        
        // Update selected platform input
        const platform = this.getAttribute('data-platform');
        const platformName = this.querySelector('.platform-name').textContent;
        
        document.getElementById('selectedPlatform').value = platformName;
        currentPlatform = platform;
        
        console.log('Selected platform:', platform);
    });
});

// ===================================
// ADMIN LOGIN
// ===================================

document.getElementById('adminLoginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('adminEmail').value;
    const password = document.getElementById('adminPassword').value;
    const platform = currentPlatform;
    
    // Validate inputs
    if (!email || !password) {
        showNotification('Please enter email and password', 'error');
        return;
    }
    
    // Check credentials
    const credentials = ADMIN_CREDENTIALS[platform];
    
    if (credentials && credentials.email === email && credentials.password === password) {
        // Login successful
        currentAdmin = credentials;
        isLoggedIn = true;
        
        // Save to storage
        saveToStorage('adminSession', {
            platform: platform,
            admin: credentials,
            timestamp: Date.now()
        });
        
        showNotification(`Welcome, ${credentials.name}!`, 'success');
        
        // Show dashboard
        showAdminDashboard(platform);
    } else {
        showNotification('Invalid credentials. Please try again.', 'error');
    }
});

function showAdminDashboard(platform) {
    // Hide login section
    document.getElementById('adminLoginSection').classList.add('hidden');
    
    // Show dashboard
    document.getElementById('adminDashboard').classList.remove('hidden');
    
    // Update platform name
    const platformNames = {
        'unified': 'Unified Dashboard',
        'ninjatech': 'NinjaTech Trading Admin',
        'sports-betting': 'Sports Betting Admin',
        'global-count': 'Global Count Admin',
        'commodity': 'Commodity Market Admin'
    };
    
    document.getElementById('currentPlatformName').textContent = platformNames[platform] || 'Admin Dashboard';
    document.getElementById('adminEmailDisplay').textContent = currentAdmin.email;
    
    // Update dashboard content
    updateDashboardStats();
    loadPlatformBalances();
    loadRecentTransactions();
}

function logoutAdmin() {
    // Clear session
    removeFromStorage('adminSession');
    
    // Reset state
    currentAdmin = null;
    isLoggedIn = false;
    currentPlatform = 'unified';
    
    // Show login section
    document.getElementById('adminLoginSection').classList.remove('hidden');
    document.getElementById('adminDashboard').classList.add('hidden');
    
    showNotification('Logged out successfully', 'info');
}

// ===================================
// NAVIGATION
// ===================================

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all links
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        
        // Add active class to clicked link
        this.classList.add('active');
        
        // Get section
        const section = this.getAttribute('data-section');
        
        // Hide all sections
        document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
        
        // Show selected section
        const sectionElement = document.getElementById(section + 'Section');
        if (sectionElement) {
            sectionElement.classList.add('active');
        }
        
        // Update page title
        const titles = {
            'overview': 'Dashboard Overview',
            'users': 'User Management',
            'transactions': 'Transaction Management',
            'wallet': 'Wallet Management',
            'platforms': 'Platform Management',
            'reports': 'Reports & Analytics',
            'settings': 'Settings'
        };
        
        document.getElementById('pageTitle').textContent = titles[section] || 'Dashboard';
        
        // Load section content
        loadSectionContent(section);
    });
});

function loadSectionContent(section) {
    switch(section) {
        case 'overview':
            updateDashboardStats();
            loadPlatformBalances();
            loadRecentTransactions();
            break;
        case 'users':
            loadUsers();
            break;
        case 'transactions':
            loadAllTransactions();
            break;
        case 'wallet':
            loadWalletInfo();
            break;
        default:
            console.log('Loading section:', section);
    }
}

// ===================================
// DASHBOARD STATS
// ===================================

function updateDashboardStats() {
    // Get wallet data
    const totalBalance = unifiedWallet.getTotalBalance();
    const transactions = unifiedWallet.getTransactions('all', 1000);
    const totalRevenue = unifiedWallet.getTotalFees('all');
    
    // Update UI
    document.getElementById('totalBalance').textContent = formatCurrency(totalBalance);
    document.getElementById('totalTransactions').textContent = transactions.length;
    document.getElementById('totalRevenue').textContent = formatCurrency(totalRevenue);
    document.getElementById('totalWalletBalance').textContent = formatCurrency(totalBalance);
    
    // Load user count from all platforms
    let totalUsers = 0;
    Object.keys(PLATFORMS).forEach(platform => {
        const platformData = getFromStorage(platform + '_users');
        if (platformData) {
            totalUsers += platformData.length || 0;
        }
    });
    document.getElementById('totalUsers').textContent = totalUsers;
}

// ===================================
// PLATFORM BALANCES
// ===================================

function loadPlatformBalances() {
    const balances = unifiedWallet.getPlatformBalances();
    
    document.getElementById('ninjatechBalance').textContent = formatCurrency(balances.ninjatech);
    document.getElementById('sportsBettingBalance').textContent = formatCurrency(balances.sportsBetting);
    document.getElementById('globalCountBalance').textContent = formatCurrency(balances.globalCount);
    document.getElementById('commodityBalance').textContent = formatCurrency(balances.commodity);
}

// ===================================
// TRANSACTIONS
// ===================================

function loadRecentTransactions() {
    const transactions = unifiedWallet.getTransactions('all', 10);
    const tbody = document.getElementById('recentTransactionsBody');
    
    if (transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No transactions found</td></tr>';
        return;
    }
    
    tbody.innerHTML = transactions.map(t => `
        <tr>
            <td>${t.id}</td>
            <td><span class="badge ${getTransactionBadgeClass(t.type)}">${t.type}</span></td>
            <td>${formatPlatformName(t.platform)}</td>
            <td>${formatCurrency(t.amount)}</td>
            <td><span class="badge badge-${t.status === 'completed' ? 'success' : 'warning'}">${t.status}</span></td>
            <td>${formatDateTime(t.timestamp)}</td>
        </tr>
    `).join('');
}

function loadAllTransactions() {
    const typeFilter = document.getElementById('transactionTypeFilter').value;
    const platformFilter = document.getElementById('transactionPlatformFilter').value;
    
    let transactions = unifiedWallet.getTransactions('all', 100);
    
    // Apply filters
    if (typeFilter !== 'all') {
        transactions = transactions.filter(t => t.type === typeFilter);
    }
    
    if (platformFilter !== 'all') {
        transactions = transactions.filter(t => 
            t.platform === platformFilter || 
            t.fromPlatform === platformFilter || 
            t.toPlatform === platformFilter
        );
    }
    
    const tbody = document.getElementById('allTransactionsBody');
    
    if (transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">No transactions found</td></tr>';
        return;
    }
    
    tbody.innerHTML = transactions.map(t => `
        <tr>
            <td>${t.id}</td>
            <td><span class="badge ${getTransactionBadgeClass(t.type)}">${t.type}</span></td>
            <td>${formatPlatformName(t.platform || t.fromPlatform)}</td>
            <td>${formatCurrency(t.amount)}</td>
            <td>${formatCurrency(t.fee || 0)}</td>
            <td><span class="badge badge-${t.status === 'completed' ? 'success' : 'warning'}">${t.status}</span></td>
            <td>${formatDateTime(t.timestamp)}</td>
        </tr>
    `).join('');
}

function getTransactionBadgeClass(type) {
    const classes = {
        'deposit': 'badge-success',
        'withdrawal': 'badge-danger',
        'transfer': 'badge-info',
        'admin_adjustment': 'badge-warning'
    };
    return classes[type] || 'badge-primary';
}

function formatPlatformName(platform) {
    const names = {
        'ninjatech': 'NinjaTech',
        'sportsBetting': 'Sports Betting',
        'sports-betting': 'Sports Betting',
        'globalCount': 'Global Count',
        'global-count': 'Global Count',
        'commodity': 'Commodity',
        'unified': 'Unified'
    };
    return names[platform] || platform;
}

// ===================================
// USERS
// ===================================

function loadUsers() {
    const usersList = document.getElementById('usersList');
    const search = document.getElementById('userSearch').value.toLowerCase();
    const platformFilter = document.getElementById('userPlatformFilter').value;
    
    let allUsers = [];
    
    // Load users from all platforms
    Object.keys(PLATFORMS).forEach(platform => {
        const platformData = getFromStorage(platform + '_users');
        if (platformData) {
            platformData.forEach(user => {
                allUsers.push({ ...user, platform: platform });
            });
        }
    });
    
    // Apply filters
    if (platformFilter !== 'all') {
        allUsers = allUsers.filter(u => u.platform === platformFilter);
    }
    
    if (search) {
        allUsers = allUsers.filter(u => 
            u.name?.toLowerCase().includes(search) || 
            u.email?.toLowerCase().includes(search)
        );
    }
    
    if (allUsers.length === 0) {
        usersList.innerHTML = '<div class="text-center p-lg">No users found</div>';
        return;
    }
    
    usersList.innerHTML = `
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Platform</th>
                        <th>Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${allUsers.map(u => `
                        <tr>
                            <td>${u.name || 'N/A'}</td>
                            <td>${u.email || 'N/A'}</td>
                            <td><span class="badge badge-info">${formatPlatformName(u.platform)}</span></td>
                            <td>${formatCurrency(u.balance || 0)}</td>
                            <td><span class="badge badge-${u.blocked ? 'danger' : 'success'}">${u.blocked ? 'Blocked' : 'Active'}</span></td>
                            <td>
                                <button class="btn btn-sm btn-outline" onclick="viewUser('${u.id}')">View</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

// ===================================
// WALLET TRANSFER
// ===================================

function platformTransfer(platform) {
    document.getElementById('transferFromPlatform').value = platform;
    showModal('transferModal');
    calculateTransferFee();
}

document.getElementById('transferAmount').addEventListener('input', calculateTransferFee);
document.getElementById('transferFromPlatform').addEventListener('change', calculateTransferFee);
document.getElementById('transferToPlatform').addEventListener('change', calculateTransferFee);

function calculateTransferFee() {
    const amount = parseFloat(document.getElementById('transferAmount').value) || 0;
    const fee = calculateTransactionFee(amount);
    const netAmount = calculateNetAmount(amount);
    
    document.getElementById('transferFee').value = formatCurrency(fee);
    document.getElementById('transferNetAmount').value = formatCurrency(netAmount);
}

function executeTransfer() {
    const fromPlatform = document.getElementById('transferFromPlatform').value;
    const toPlatform = document.getElementById('transferToPlatform').value;
    const amount = parseFloat(document.getElementById('transferAmount').value);
    
    // Validate
    if (!amount || amount <= 0) {
        showNotification('Please enter a valid amount', 'error');
        return;
    }
    
    if (fromPlatform === toPlatform) {
        showNotification('Cannot transfer to the same platform', 'error');
        return;
    }
    
    // Execute transfer
    const result = unifiedWallet.transfer(amount, fromPlatform, toPlatform);
    
    if (result.success) {
        showNotification(`Transfer of ${formatCurrency(amount)} successful!`, 'success');
        hideModal('transferModal');
        
        // Update UI
        updateDashboardStats();
        loadPlatformBalances();
        loadRecentTransactions();
        
        // Reset form
        document.getElementById('transferForm').reset();
        document.getElementById('transferFee').value = '';
        document.getElementById('transferNetAmount').value = '';
    } else {
        showNotification(result.message, 'error');
    }
}

// ===================================
// TOGGLE SIDEBAR
// ===================================

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('active');
}

// ===================================
// INITIALIZATION
// ===================================

document.addEventListener('DOMContentLoaded', function() {
    // Check for existing session
    const session = getFromStorage('adminSession');
    if (session && session.admin) {
        currentAdmin = session.admin;
        currentPlatform = session.platform;
        isLoggedIn = true;
        
        showAdminDashboard(currentPlatform);
    }
    
    // Add event listeners for filters
    document.getElementById('userSearch')?.addEventListener('input', loadUsers);
    document.getElementById('userPlatformFilter')?.addEventListener('change', loadUsers);
    document.getElementById('transactionTypeFilter')?.addEventListener('change', loadAllTransactions);
    document.getElementById('transactionPlatformFilter')?.addEventListener('change', loadAllTransactions);
    
    console.log('Unified Admin System initialized');
    console.log('Available platforms:', Object.keys(ADMIN_CREDENTIALS));
});

// ===================================
// HELPER FUNCTIONS
// ===================================

function viewAllTransactions() {
    document.querySelector('[data-section="transactions"]').click();
}

function showNotifications() {
    showNotification('No new notifications', 'info');
}

function showQuickDeposit() {
    showNotification('Deposit feature coming soon', 'info');
}

function viewUser(userId) {
    showNotification(`Viewing user ${userId}`, 'info');
}

function loadWalletInfo() {
    showNotification('Wallet management coming soon', 'info');
}