# 🎛️ Unified Admin System
## Global Trading Platforms - Complete Administration Solution

---

## 📋 Overview

The Unified Admin System provides a centralized dashboard to manage all four trading platforms from a single interface. It features cross-platform wallet integration, unified transaction monitoring, and seamless fund transfers between platforms.

---

## 🚀 Quick Start

### Access the Unified Admin Dashboard
1. Open `unified-admin/index.html` in your browser
2. Select a platform to administer (or "Unified Dashboard" for all platforms)
3. Enter admin credentials
4. Access all platform features from one dashboard

### Login Credentials

| Platform | Email | Password |
|----------|-------|----------|
| **Unified (Master)** | admin@globaltrading.com | MasterAdmin@2024 |
| **NinjaTech Trading** | admin@ninjatech.com | NinjaTech@2024 |
| **Sports Betting** | admin@sportsbetting.com | SportsBetting@2024 |
| **Global Count** | adeganglobal@gmail.com | admin123 |
| **Commodity Market** | admin@commoditymarket.com | CommodityMarket@2024 |

---

## 📁 File Structure

```
/workspace/
├── unified-admin/
│   ├── index.html              # Unified Admin Dashboard
│   ├── admin.css              # Admin Dashboard Styles
│   ├── admin.js               # Admin Dashboard Logic
│   └── README.md              # This File
├── shared-components/
│   ├── css/
│   │   └── common.css         # Shared Styles for All Platforms
│   └── js/
│       ├── common.js          # Shared Utilities
│       └── wallet-system.js   # Unified Wallet System
├── ninjatech-enhanced-trading/
│   ├── index.html             # NinjaTech Platform (with admin panel)
│   ├── styles.css
│   └── script.js
├── sports-betting-casino/
│   ├── index.html             # Sports Betting Platform (with admin panel)
│   ├── styles.css
│   └── script.js
├── global-count-trading/
│   ├── index.html             # Global Count Platform (with existing admin)
│   ├── styles.css
│   └── script.js
├── global-commodity-market/
│   ├── index.html             # Commodity Market Platform (with admin panel)
│   ├── styles.css
│   └── script.js
└── ADMIN_CREDENTIALS.md       # Complete Admin Credentials Guide
```

---

## ✨ Features

### Unified Admin Dashboard

1. **Multi-Platform Management**
   - View all platforms from one dashboard
   - Switch between platforms easily
   - Cross-platform user management
   - Unified transaction monitoring

2. **Wallet Integration**
   - Total balance across all platforms
   - Platform-specific balances
   - Cross-platform transfers (2% fee)
   - Complete transaction history

3. **Statistics & Reports**
   - Total users across all platforms
   - Total transactions and revenue
   - Platform-specific metrics
   - Real-time updates

4. **Quick Actions**
   - Deposit funds
   - Process withdrawals
   - Manage users
   - View reports

### Individual Platform Admin Panels

Each platform has its own admin panel with platform-specific features:

- **NinjaTech Trading:** MT4/5 integration, trading account management
- **Sports Betting:** Bet management, casino game controls
- **Global Count:** Matrix pool management, payout processing
- **Commodity Market:** Price management, investment monitoring

---

## 🔧 Shared Components

### 1. Common CSS (`shared-components/css/common.css`)
- Consistent styling across all platforms
- Dark theme design
- Responsive layout
- Utility classes
- Button, card, form, table styles
- Modal and notification styles

### 2. Common JS (`shared-components/js/common.js`)
- Currency formatting (NGN)
- Date/time formatting
- Storage management (localStorage)
- Notification system
- Validation functions
- Modal management
- Helper utilities

### 3. Wallet System (`shared-components/js/wallet-system.js`)
- Unified balance tracking
- Cross-platform transfers
- Transaction management
- Fee calculation (2%)
- Balance history
- Admin adjustments

---

## 💼 Platform Integration

### Unified Wallet System

All platforms share the same wallet system:

```javascript
// Example: Transfer between platforms
unifiedWallet.transfer(50000, 'ninjatech', 'sportsBetting');

// Get total balance
const totalBalance = unifiedWallet.getTotalBalance();

// Get platform-specific balance
const commodityBalance = unifiedWallet.getBalance('commodity');
```

### Data Storage

- All data stored in browser localStorage
- Each platform maintains its own data
- Unified wallet aggregates all platform data
- Clear cache to reset all data

### Transaction Flow

1. **Deposit:** Add funds to any platform or unified wallet
2. **Transfer:** Move funds between platforms (2% fee)
3. **Withdraw:** Withdraw from any platform (2% fee)
4. **Track:** Complete transaction history maintained

---

## 📊 Admin Dashboard Sections

### 1. Overview
- Total users, balance, transactions, revenue
- Platform-specific balances
- Recent transactions
- Quick statistics

### 2. Users
- User management across all platforms
- Search and filter users
- View user details
- Block/unblock users

### 3. Transactions
- Complete transaction history
- Filter by type and platform
- View transaction details
- Export reports

### 4. Wallet
- Unified wallet management
- Cross-platform transfers
- Balance adjustments (admin)
- Transaction fees

### 5. Platforms
- Platform-specific settings
- Quick links to individual platforms
- Platform status monitoring
- Configuration options

### 6. Reports
- Financial reports
- User activity reports
- Platform performance
- Revenue analytics

---

## 🔐 Security Notes

- **Default passwords should be changed after first login**
- **Never share admin credentials publicly**
- **Use strong, unique passwords**
- **Clear browser cache when needed**
- **Each platform has separate admin access**

---

## 🌐 Platform Links

Quick access to all platforms:

- **Unified Admin:** `unified-admin/index.html`
- **NinjaTech Trading:** `ninjatech-enhanced-trading/index.html`
- **Sports Betting & Casino:** `sports-betting-casino/index.html`
- **Global Count Trading:** `global-count-trading/index.html`
- **Commodity Market:** `global-commodity-market/index.html`

---

## 📱 Responsive Design

All platforms are fully responsive:
- Desktop: Full dashboard experience
- Tablet: Optimized sidebar and layout
- Mobile: Touch-friendly interface

---

## 🆘 Support

### System Owner
**Olawale Abdul-Ganiyu Adeshina**
- **Email:** adeganglobal@gmail.com
- **Phone:** +2349030277275
- **Location:** Ikeja, Lagos, Ogun State, Nigeria

### Troubleshooting

1. **Login Issues:** Verify email and password
2. **Balance Issues:** Check wallet history
3. **Transfer Issues:** Ensure sufficient balance
4. **Platform Issues:** Clear browser cache
5. **Data Issues:** Check localStorage

---

## 📅 Version History

### Version 1.0 (Current)
- ✅ Unified Admin Dashboard
- ✅ Shared Components (CSS, JS)
- ✅ Wallet Integration
- ✅ Cross-Platform Transfers
- ✅ Individual Platform Admin Panels
- ✅ Complete Admin Credentials
- ✅ Platform Linking
- ✅ Transaction Monitoring

---

## 📝 License & Usage

This system is owned and operated by Olawale Abdul-Ganiyu Adeshina. All rights reserved.

---

## 🎯 Next Steps

1. Test all admin login credentials
2. Verify cross-platform transfers work
3. Test individual platform admin panels
4. Review transaction history
5. Customize settings as needed

---

**System Version:** 1.0.0  
**Last Updated:** 2024  
**Platform Status:** All Systems Operational  
**Admin Credentials:** See ADMIN_CREDENTIALS.md